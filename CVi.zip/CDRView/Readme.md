# Synapse JSON Reader (ABFSS)

Reads JSON files one-by-one from Azure Data Lake Storage Gen2 using service principal auth.

## Install
```bash
pip install -r requirements.txt
