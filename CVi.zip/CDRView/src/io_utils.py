from typing import List, Iterable
import json
import fsspec
from urllib.parse import urlparse
from .logger import info

def load_json(path: str):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def is_abfs_uri(uri: str) -> bool:
    scheme = urlparse((uri or "").strip()).scheme.lower()
    return scheme in ("abfs", "abfss")

def get_fs_for_path(path_root: str, secrets: dict):
    """
    Pick filesystem by URI scheme (robust). abfs/abfss => ADLS Gen2; else local.
    """
    if is_abfs_uri(path_root):
        return fsspec.filesystem(
            "abfss",
            account_name=secrets["account_name"],
            tenant_id=secrets["tenant_id"],
            client_id=secrets["client_id"],
            client_secret=secrets["client_secret"],
        )
    return fsspec.filesystem("file")

def iter_files(fs, root: str, recursive: bool = True, include_ext: List[str] = None) -> Iterable[str]:
    """
    Yield file paths under `root`. If recursive, walk the tree; otherwise list only the top-level.
    Filters by file extension if include_ext is provided.
    """
    root = (root or "").rstrip("/")
    include_ext = [e.lower() for e in (include_ext or [])]

    def _want(p: str) -> bool:
        if fs.isdir(p): return False
        if not include_ext: return True
        pl = p.lower()
        return any(pl.endswith(ext) for ext in include_ext)

    listed = False

    # Prefer precise APIs (ls/find) over wildcard globbing (more reliable on abfss)
    if recursive:
        try:
            for p in fs.find(root):
                if _want(p):
                    yield p
            listed = True
        except Exception:
            pass

    if not listed:
        try:
            for p in fs.ls(root, detail=False):
                if _want(p):
                    yield p
            listed = True
        except Exception:
            pass

    if not listed:
        # Last resort: recursive glob
        pattern = root + ("/**/*" if recursive else "/*")
        for p in fs.glob(pattern):
            if _want(p) and not fs.isdir(p):
                yield p

    info("Listing complete", root=root, recursive=recursive)
