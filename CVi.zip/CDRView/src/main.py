#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
from .logger import info, warn, err, get_logfile_path, RUN_ID
from .io_utils import load_json, get_fs_for_path, iter_files
from .processor import process_json_bytes

def run(settings_path: str, secrets_path: str):
    settings = load_json(settings_path)
    secrets  = load_json(secrets_path)

    input_root  = settings["input_root"].strip()
    recursive   = bool(settings.get("recursive", True))
    max_files   = int(settings.get("max_files", 0))
    include_ext = settings.get("include_ext", [".json"])
    log_dir     = settings.get("log_dir", "logs")  # just to show in startup log

    info("Run started", run_id=RUN_ID, logfile=get_logfile_path(), input_root=input_root, log_dir=log_dir)

    fs = get_fs_for_path(input_root, secrets)

    count = 0
    try:
        for idx, path in enumerate(iter_files(fs, input_root, recursive=recursive, include_ext=include_ext), start=1):
            info("Reading file", file=path, counter=idx)
            with fs.open(path, "rb") as f:
                data = f.read()

            try:
                process_json_bytes(path, data)
            except Exception as e:
                err("Process failed", file=path, error=str(e))
                continue

            count += 1
            if max_files > 0 and count >= max_files:
                warn("Max files reached; stopping early", max_files=max_files)
                break

            if count % 1000 == 0:
                info("Progress", processed=count)
    except Exception as e:
        err("Listing/Read failed", error=str(e))

    info("Run finished", processed=count, run_id=RUN_ID, logfile=get_logfile_path())

def main():
    ap = argparse.ArgumentParser(description="Read JSON files from ADLS Gen2 (ABFSS) one by one.")
    ap.add_argument("--settings", default="config/settings.json")
    ap.add_argument("--secrets",  default="config/secrets.json")
    args = ap.parse_args()
    run(args.settings, args.secrets)

if __name__ == "__main__":
    main()
