import json
from .logger import info

def process_json_bytes(path: str, data: bytes):
    """
    Your per-file hook: do whatever you need here.
    For now, we just parse JSON, log a key, and return.
    """
    try:
        obj = json.loads(data.decode("utf-8"))
    except Exception:
        # If you have non-UTF8 or compressed files, handle here.
        raise

    # Example: log the callRecordId if present
    rec_id = obj.get("id") or obj.get("callRecordId")
    info("Processed JSON", file=path, callRecordId=rec_id)
    # TODO: replace with your real processing (write to DB, send to queue, transform, etc.)
