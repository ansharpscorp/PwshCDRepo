synapse-json-reader/
├─ config/
│  ├─ secrets.json         # service principal + storage info
│  └─ settings.json        # input path and options
├─ src/
│  ├─ main.py              # CLI entrypoint
│  ├─ io_utils.py          # ABFSS/local FS, safe listing
│  ├─ logger.py            # console + timestamped logfile
│  └─ processor.py         # your per-file processing hook
├─ requirements.txt
└─ README.md
