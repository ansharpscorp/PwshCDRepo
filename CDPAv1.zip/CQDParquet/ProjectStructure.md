TeamsCallAnalysis/
│
├── main.py
├── processor.py
├── io_handler_async.py
├── utils.py
├── logger.py
├── config.json
├── columns.yml
├── requirements.txt
└── _Logs/
