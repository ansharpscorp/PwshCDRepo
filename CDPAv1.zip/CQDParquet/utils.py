from datetime import datetime, timedelta

def generate_date_range(start, end):
    s = datetime.strptime(start, "%Y-%m-%d")
    e = datetime.strptime(end, "%Y-%m-%d")
    return [(s + timedelta(days=i)).strftime("%Y%m%d") for i in range((e - s).days + 1)]
