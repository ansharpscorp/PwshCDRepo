
import asyncio
import aiohttp
import os
import json
from config import GRAPH_URL, OUTPUT_FOLDER

async def fetch_records(session, token, start_time, end_time):
    url = f"{GRAPH_URL}?$filter=startDateTime ge {start_time} and startDateTime lt {end_time}"
    headers = {'Authorization': f'Bearer {token}'}
    records = []
    while url:
        async with session.get(url, headers=headers) as resp:
            data = await resp.json()
            records.extend(data.get('value', []))
            url = data.get('@odata.nextLink')
    return records

async def fetch_expand_data(session, token, record_id, endpoint):
    url = f"{GRAPH_URL}/{record_id}/{endpoint}"
    headers = {'Authorization': f'Bearer {token}'}
    all_data = []
    while url:
        async with session.get(url, headers=headers) as resp:
            data = await resp.json()
            all_data.extend(data.get('value', []))
            url = data.get('@odata.nextLink')
    return all_data

async def process_record(session, token, rec):
    record_id = rec['id']
    sessions = await fetch_expand_data(session, token, record_id, 'sessions?$expand=segments')
    participants_v2 = await fetch_expand_data(session, token, record_id, 'participants_v2')

    result = {
        "endDateTime": rec.get("endDateTime"),
        "id": rec.get("id"),
        "joinWebUrl": rec.get("joinWebUrl"),
        "lastModifiedDateTime": rec.get("lastModifiedDateTime"),
        "modalities": rec.get("modalities"),
        "organizer": rec.get("organizer"),
        "participants": rec.get("participants"),
        "startDateTime": rec.get("startDateTime"),
        "type": rec.get("type"),
        "version": rec.get("version"),
        "participants_v2": participants_v2,
        "sessions": sessions
    }
    path = os.path.join(OUTPUT_FOLDER, f"{record_id}.json")
    with open(path, 'w') as f:
        json.dump(result, f)

async def fetch_interval_async(token, start_time, end_time):
    async with aiohttp.ClientSession() as session:
        records = await fetch_records(session, token, start_time, end_time)
        await asyncio.gather(*[process_record(session, token, rec) for rec in records])

def fetch_interval(token, start_time, end_time):
    asyncio.run(fetch_interval_async(token, start_time, end_time))
