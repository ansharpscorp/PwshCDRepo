
import os
import json
import logging
from config import *
from auth_helper import get_token
from fetcher import fetch_interval
from multiprocessing import Pool, cpu_count
from datetime import datetime, timedelta

def ensure_output_folder():
    if not os.path.exists(OUTPUT_FOLDER):
        os.makedirs(OUTPUT_FOLDER)

def process_day(token, date_str):
    date = datetime.strptime(date_str, '%Y-%m-%d')
    intervals = []
    for i in range(0, 96):
        start = date + timedelta(minutes=15 * i)
        end = start + timedelta(minutes=15)
        intervals.append((token, start.isoformat() + 'Z', end.isoformat() + 'Z'))

    with Pool(cpu_count()) as pool:
        pool.starmap(fetch_interval, intervals)

if __name__ == '__main__':
    ensure_output_folder()
    token = get_token()
    process_day(token, '2025-05-01')
