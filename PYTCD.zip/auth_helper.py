
import requests
from config import *

def get_token():
    data = {
        'client_id': CLIENT_ID,
        'scope': SCOPE,
        'client_secret': CLIENT_SECRET,
        'grant_type': 'client_credentials'
    }
    response = requests.post(TOKEN_URL, data=data)
    response.raise_for_status()
    return response.json()['access_token']
