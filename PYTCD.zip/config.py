
TENANT_ID = '<your-tenant-id>'
CLIENT_ID = '<your-client-id>'
CLIENT_SECRET = '<your-client-secret>'
SCOPE = 'https://graph.microsoft.com/.default'
TOKEN_URL = f'https://login.microsoftonline.com/{TENANT_ID}/oauth2/v2.0/token'
GRAPH_URL = 'https://graph.microsoft.com/v1.0/communications/callRecords'
OUTPUT_FOLDER = 'output'
