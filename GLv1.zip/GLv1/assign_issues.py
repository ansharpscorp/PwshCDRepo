import os
from gitlab_api import get_open_issues, assign_issue
from issue_utils import is_unassigned

ASSIGNEE_IDS = [int(i) for i in os.environ['ASSIGNEE_IDS'].split(',')]

def main():
    issues = get_open_issues()
    for issue in issues:
        if is_unassigned(issue):
            ok, api_resp = assign_issue(issue['iid'], ASSIGNEE_IDS)
            if ok:
                print(f"[SUCCESS] Assigned issue #{issue['iid']} to {ASSIGNEE_IDS}")
            else:
                print(f"[FAILED] Failed to assign issue #{issue['iid']} to {ASSIGNEE_IDS}: {api_resp}")
        else:
            print(f"Issue #{issue['iid']} already assigned, skipping.")

if __name__ == "__main__":
    main()
