import os
import requests

GITLAB_API_URL = os.environ['GITLAB_API_URL']
PRIVATE_TOKEN = os.environ['PRIVATE_TOKEN']
PROJECT_ID = os.environ['PROJECT_ID']

def get_open_issues():
    """Fetch all OPEN issues in the project (paginated)"""
    issues = []
    page = 1
    while True:
        url = f"{GITLAB_API_URL}/projects/{PROJECT_ID}/issues"
        params = {"per_page": 100, "page": page, "state": "opened"}
        resp = requests.get(url, headers={"PRIVATE-TOKEN": PRIVATE_TOKEN}, params=params)
        resp.raise_for_status()
        batch = resp.json()
        if not batch:
            break
        issues.extend(batch)
        page += 1
    return issues

def assign_issue(issue_iid, assignee_ids):
    """Assign an issue to the list of user IDs"""
    url = f"{GITLAB_API_URL}/projects/{PROJECT_ID}/issues/{issue_iid}"
    resp = requests.put(
        url,
        headers={"PRIVATE-TOKEN": PRIVATE_TOKEN},
        json={"assignee_ids": assignee_ids}
    )
    if resp.status_code == 200:
        print(f"Issue #{issue_iid} assigned to {assignee_ids}")
        return True, resp.text
    else:
        print(f"Failed to assign issue #{issue_iid}: {resp.status_code} - {resp.text}")
        return False, resp.text
