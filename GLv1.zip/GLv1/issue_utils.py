def is_unassigned(issue):
    """Returns True if the issue has no assignees"""
    return not issue.get('assignees')
