
using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.IO;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;

namespace TeamsCdrDownloaderCs
{
    public static class Fetcher
    {
        public static async Task FetchIntervalAsync(string token, string startTime, string endTime)
        {
            var client = new HttpClient();
            client.DefaultRequestHeaders.Add("Authorization", $"Bearer {token}");
            var url = $"{Config.GraphUrl}?$filter=startDateTime ge {startTime} and startDateTime lt {endTime}";
            var response = await client.GetStringAsync(url);
            var json = JObject.Parse(response);
            var records = json["value"];
            foreach (var record in records)
            {
                await ProcessRecordAsync(token, record);
            }
        }

        private static async Task ProcessRecordAsync(string token, JToken record)
        {
            string id = record["id"].ToString();
            var sessionData = await ExpandDataAsync(token, id, "sessions?$expand=segments");
            var participantsData = await ExpandDataAsync(token, id, "participants_v2");

            var result = new JObject
            {
                ["endDateTime"] = record["endDateTime"],
                ["id"] = id,
                ["joinWebUrl"] = record["joinWebUrl"],
                ["lastModifiedDateTime"] = record["lastModifiedDateTime"],
                ["modalities"] = record["modalities"],
                ["organizer"] = record["organizer"],
                ["participants"] = record["participants"],
                ["startDateTime"] = record["startDateTime"],
                ["type"] = record["type"],
                ["version"] = record["version"],
                ["participants_v2"] = participantsData["value"],
                ["sessions"] = sessionData["value"]
            };

            File.WriteAllText(Path.Combine(Config.OutputFolder, $"{id}.json"), result.ToString(Formatting.Indented));
        }

        private static async Task<JObject> ExpandDataAsync(string token, string id, string endpoint)
        {
            var client = new HttpClient();
            client.DefaultRequestHeaders.Add("Authorization", $"Bearer {token}");
            var url = $"{Config.GraphUrl}/{id}/{endpoint}";
            var response = await client.GetStringAsync(url);
            return JObject.Parse(response);
        }
    }
}
