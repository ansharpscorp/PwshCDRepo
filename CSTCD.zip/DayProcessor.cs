
using System;
using System.Threading.Tasks;
using System.IO;

namespace TeamsCdrDownloaderCs
{
    public class DayProcessor
    {
        private string token;

        public DayProcessor(string token) => this.token = token;

        public async Task ProcessDayAsync(string dateStr)
        {
            DateTime date = DateTime.Parse(dateStr);
            Directory.CreateDirectory(Config.OutputFolder);

            for (int i = 0; i < 96; i++)
            {
                DateTime start = date.AddMinutes(15 * i);
                DateTime end = start.AddMinutes(15);
                await Fetcher.FetchIntervalAsync(token, start.ToString("o"), end.ToString("o"));
            }
        }
    }
}
