
using System.Net.Http;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace TeamsCdrDownloaderCs
{
    public static class AuthHelper
    {
        public static async Task<string> GetTokenAsync()
        {
            var client = new HttpClient();
            var values = new Dictionary<string, string>
            {
                { "client_id", Config.ClientId },
                { "scope", Config.Scope },
                { "client_secret", Config.ClientSecret },
                { "grant_type", "client_credentials" }
            };
            var content = new FormUrlEncodedContent(values);
            var response = await client.PostAsync(Config.TokenUrl, content);
            var json = await response.Content.ReadAsStringAsync();
            dynamic result = Newtonsoft.Json.JsonConvert.DeserializeObject(json);
            return result.access_token;
        }
    }
}
