
using System;
using System.Threading.Tasks;

namespace TeamsCdrDownloaderCs
{
    class Program
    {
        static async Task Main(string[] args)
        {
            var token = await AuthHelper.GetTokenAsync();
            var processor = new DayProcessor(token);
            await processor.ProcessDayAsync("2025-05-01");
        }
    }
}
