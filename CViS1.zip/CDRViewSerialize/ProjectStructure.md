json2parquet-1to1/
├─ config/
│  ├─ secrets.json
│  ├─ settings.json          ← UPDATED (adds start_date & end_date)
│  └─ columns.yml
├─ src/
│  ├─ main.py                ← UPDATED (date-range aware)
│  ├─ io_utils.py            ← UPDATED (date helpers)
│  ├─ flattener.py
│  ├─ writer.py
│  ├─ logger.py
│  └─ __init__.py
├─ requirements.txt
└─ README.md
