#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
from dateutil.parser import isoparse

from .logger import info, warn, err, get_logfile_path, RUN_ID
from .io_utils import (
    load_json, load_yaml, get_fs_for_path, iter_files,
    to_relative_path, join_uri, replace_ext,
    daterange, month_mmm, day_dd
)
from .flattener import parse_json_bytes, flatten_callrecord
from .writer import write_parquet_one_file

def run(settings_path: str, secrets_path: str, columns_path: str):
    settings = load_json(settings_path)
    secrets  = load_json(secrets_path)
    columns  = load_yaml(columns_path)

    input_root   = settings["input_root"].strip()
    output_root  = settings["output_root"].strip()
    start_date   = isoparse(settings["start_date"]).date()
    end_date     = isoparse(settings["end_date"]).date()
    recursive_day = bool(settings.get("recursive_day", False))
    include_ext  = settings.get("include_ext", [".json"])
    compression  = settings.get("compression", "snappy")
    log_dir      = settings.get("log_dir", "logs")

    info("Run started", run_id=RUN_ID, logfile=get_logfile_path(),
         input_root=input_root, output_root=output_root,
         start_date=str(start_date), end_date=str(end_date),
         recursive_day=recursive_day, log_dir=log_dir)

    fs_in  = get_fs_for_path(input_root, secrets)
    fs_out = get_fs_for_path(output_root, secrets)

    total_files_written = 0

    # Iterate day folders between start_date and end_date
    for d in daterange(start_date, end_date):
        y    = f"{d.year}"
        mmm  = month_mmm(d)     # e.g., "Sep"
        dd   = day_dd(d)        # "22"

        day_folder = join_uri(input_root, y, mmm, dd)
        info("Processing day", day=str(d), folder=day_folder)

        # List files in this day folder (optionally recursive for subfolders)
        files = list(iter_files(fs_in, day_folder, recursive=recursive_day, include_ext=include_ext))
        if not files:
            warn("No files found for day", day=str(d), folder=day_folder)
            continue

        # Process each file: 1 JSON => 1 Parquet with same name/relative path
        for idx, in_path in enumerate(files, start=1):
            try:
                info("Reading file", file=in_path, counter=idx, total=len(files))
                with fs_in.open(in_path, "rb") as f:
                    data = f.read()

                rec = parse_json_bytes(data)
                rows = list(flatten_callrecord(rec))

                rel = to_relative_path(input_root, in_path)
                out_rel = replace_ext(rel, ".parquet")
                out_path = join_uri(output_root, out_rel)

                write_parquet_one_file(fs_out, out_path, rows, columns=columns, compression=compression)
                total_files_written += 1
            except Exception as e:
                err("Failed file", file=in_path, error=str(e))

        info("Day complete", day=str(d), files=len(files))

    info("Run finished", processed=total_files_written, run_id=RUN_ID, logfile=get_logfile_path())

def main():
    ap = argparse.ArgumentParser(description="JSON → Parquet (1:1) with date range over YYYY/MMM/dd folders.")
    ap.add_argument("--settings", default="config/settings.json")
    ap.add_argument("--secrets",  default="config/secrets.json")
    ap.add_argument("--columns",  default="config/columns.yml")
    args = ap.parse_args()
    run(args.settings, args.secrets, args.columns)

if __name__ == "__main__":
    main()
