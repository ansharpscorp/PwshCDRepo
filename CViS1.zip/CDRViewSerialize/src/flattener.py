import json
from typing import Any, Dict, Iterable

def safe_get(d, *keys, default=None):
    cur = d or {}
    for k in keys:
        if not isinstance(cur, dict) or k not in cur:
            return default
        cur = cur[k]
    return cur

def extract_identity(party: Dict[str, Any]) -> Dict[str, Any]:
    ident = party.get("associatedIdentity") or {}
    if "userPrincipalName" in ident or "tenantId" in ident:
        id_type = "user"; upn = ident.get("userPrincipalName"); phone = None
    elif "number" in ident:
        id_type = "phone"; upn = None; phone = ident.get("number")
    else:
        id_type = ident.get("@odata.type", "unknown"); upn = None; phone = ident.get("number")

    return {
        "IdentityType": id_type,
        "Id": ident.get("id"),
        "TenantId": ident.get("tenantId"),
        "DisplayName": ident.get("displayName"),
        "UPN": upn,
        "Phone": phone,
    }

def flatten_callrecord(obj: Dict[str, Any]) -> Iterable[Dict[str, Any]]:
    rec_id   = obj.get("id")
    ctype    = obj.get("type")
    cstart   = obj.get("startDateTime")
    cend     = obj.get("endDateTime")
    version  = obj.get("version")
    modalities = obj.get("modalities") or []
    sessions = obj.get("sessions") or []

    for s in sessions:
        session_id = s.get("id")
        sstart     = s.get("startDateTime")
        send       = s.get("endDateTime")
        is_test    = s.get("isTest")

        caller = s.get("caller") or {}
        callee = s.get("callee") or {}

        c_id = extract_identity(caller)
        a_id = extract_identity(callee)

        base = {
            "callRecordId": rec_id,
            "callType": ctype,
            "callStart": cstart,
            "callEnd": cend,
            "callVersion": version,
            "callModalities": ";".join(modalities) if isinstance(modalities, list) else modalities,
            "sessionId": session_id,
            "sessionStart": sstart,
            "sessionEnd": send,
            "isTest": is_test,
            "callerIdentityType": c_id["IdentityType"],
            "callerId": c_id["Id"],
            "callerTenantId": c_id["TenantId"],
            "callerDisplayName": c_id["DisplayName"],
            "callerUPN": c_id["UPN"],
            "callerPhone": c_id["Phone"],
            "calleeIdentityType": a_id["IdentityType"],
            "calleeId": a_id["Id"],
            "calleeTenantId": a_id["TenantId"],
            "calleeDisplayName": a_id["DisplayName"],
            "calleeUPN": a_id["UPN"],
            "calleePhone": a_id["Phone"],
            "calleeFeedbackRating": safe_get(callee, "feedback", "rating"),
        }

        segments = s.get("segments") or []
        yielded = False

        for seg in segments:
            seg_id = seg.get("id")
            seg_start = seg.get("startDateTime")
            seg_end   = seg.get("endDateTime")

            for media in (seg.get("media") or []):
                streams = media.get("streams") or []
                med_base = {
                    **base,
                    "segmentId": seg_id,
                    "segmentStart": seg_start,
                    "segmentEnd": seg_end,
                    "mediaLabel": media.get("label"),
                    "callerNetworkIP": safe_get(media, "callerNetwork", "ipAddress"),
                    "callerNetworkSubnet": safe_get(media, "callerNetwork", "subnet"),
                    "callerNetworkLinkSpeed": safe_get(media, "callerNetwork", "linkSpeed"),
                }

                if streams:
                    for st in streams:
                        yield {
                            **med_base,
                            "streamId": st.get("streamId"),
                            "streamDirection": st.get("streamDirection"),
                            "averageJitter": st.get("averageJitter"),
                            "averageAudioDegradation": st.get("averageAudioDegradation"),
                        }
                        yielded = True
                else:
                    yield {**med_base, "streamId": None, "streamDirection": None,
                           "averageJitter": None, "averageAudioDegradation": None}
                    yielded = True

        if not segments or not yielded:
            yield {**base, "segmentId": None, "segmentStart": None, "segmentEnd": None,
                   "mediaLabel": None, "streamId": None, "streamDirection": None,
                   "averageJitter": None, "averageAudioDegradation": None}

def parse_json_bytes(b: bytes):
    return json.loads(b.decode("utf-8"))
