from typing import Dict, List, Union, Optional
import pyarrow as pa
import pyarrow.parquet as pq
from .logger import info

ColumnSpec = Union[str, Dict[str, object]]

def _apply_column_spec(row: Dict, spec: ColumnSpec) -> Dict:
    if isinstance(spec, str):
        return {spec: row.get(spec)}
    name = spec.get("name")
    if "from" in spec:
        return {name: row.get(spec["from"])}
    if "coalesce" in spec:
        for key in spec["coalesce"]:
            val = row.get(key)
            if val is not None:
                return {name: val}
        return {name: spec.get("default")}
    return {str(name) if name else "unnamed": None}

def _filter_columns(rows: List[Dict], columns: Optional[List[ColumnSpec]]) -> List[Dict]:
    if not columns:
        return rows
    out: List[Dict] = []
    for r in rows:
        new_r: Dict = {}
        for spec in columns:
            new_r.update(_apply_column_spec(r, spec))
        out.append(new_r)
    return out

def write_parquet_one_file(fs_out, out_path: str, rows: List[Dict],
                           columns: Optional[List[ColumnSpec]] = None,
                           compression: str = "snappy"):
    filtered = _filter_columns(rows, columns)
    table = pa.Table.from_pylist(filtered)
    parent = "/".join(out_path.split("/")[:-1])
    try:
        fs_out.makedirs(parent, exist_ok=True)
    except Exception:
        pass
    with fs_out.open(out_path, "wb") as f:
        pq.write_table(table, f, compression=compression)
    info("Saved parquet", file=out_path, rows=len(filtered))
