# JSON → Parquet (1:1) with Date Range (ADLS Gen2)

This tool reads JSON files from ADLS Gen2 (or local) organized as `.../cdr/YYYY/MMM/dd/`, **only for the date range** in `settings.json`, and writes **one Parquet per JSON** to `output_root`, preserving the folder structure and filename.

## Install
```bash
pip install -r requirements.txt
