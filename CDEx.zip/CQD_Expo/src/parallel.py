from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import date
import os, logging, traceback

from runtime_ctx import RuntimeCtx
from yaml_utils import load_columns_yaml
from export_logic import ensure_required_columns, load_query_text, export_one_day

log = logging.getLogger("parallel")

def _export_one_day_worker(root: str, day_iso: str) -> list[dict]:
    try:
        ctx = RuntimeCtx(root)
        cfg = ctx.config

        date_col = cfg["source"]["date_column"]
        conf_col = cfg["source"]["conference_id_column"]

        cols = load_columns_yaml(os.path.join(root, "columns.yml"))
        cols = ensure_required_columns(cols, date_col, conf_col)

        qfile = os.path.join(root, cfg["source"]["query_file"])
        base_query = load_query_text(qfile)
        if "@p_start" not in base_query or "@p_end" not in base_query:
            raise ValueError("sql/base_query.sql must contain @p_start and @p_end in WHERE clause.")

        conn = ctx.sql_conn()
        fs   = ctx.adls_fs()

        the_day = date.fromisoformat(day_iso)
        metrics = export_one_day(
            conn=conn, fs=fs, base_output=cfg["export"]["output_base"].rstrip("/"),
            base_query=base_query, date_col=date_col, conf_col=conf_col, select_cols=cols,
            the_day=the_day, batch_conf_ids=int(cfg["export"]["batch_conference_ids"]),
            compression=cfg["export"].get("compression", "snappy"), arraysize=ctx.arraysize
        )
        conn.close()
        return metrics

    except Exception as e:
        traceback.print_exc()
        return [{
            "date": day_iso,
            "batch_index": -1,
            "ids_rn_start": None,
            "ids_rn_end": None,
            "rows": 0,
            "bytes": 0,
            "seconds": 0.0,
            "path": "",
            "error": f"{type(e).__name__}: {e}"
        }]

def run_parallel_per_day(root: str, days: list[str], max_workers: int) -> list[dict]:
    all_rows = []
    with ProcessPoolExecutor(max_workers=max_workers) as ex:
        futs = {ex.submit(_export_one_day_worker, root, d): d for d in days}
        for fut in as_completed(futs):
            d = futs[fut]
            try:
                rows = fut.result()
                all_rows.extend(rows)
                ok_err = "error" if rows and "error" in rows[0] else "ok"
                log.info(f"{d} finished ({ok_err}), files={sum(1 for r in rows if not r.get('error'))}")
            except Exception as e:
                log.exception(f"{d} worker failed: {e}")
                all_rows.append({
                    "date": d, "batch_index": -1, "ids_rn_start": None, "ids_rn_end": None,
                    "rows": 0, "bytes": 0, "seconds": 0.0, "path": "", "error": f"{type(e).__name__}: {e}"
                })
    return all_rows
