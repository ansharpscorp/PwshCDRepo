import os, csv
from datetime import datetime

def ensure_dir(path: str):
    os.makedirs(os.path.dirname(path), exist_ok=True)

def timestamp_name(prefix: str, ext: str = "csv"):
    ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    return f"{prefix}_{ts}.{ext}"

def write_local_metrics(base_folder: str, rows: list[dict]):
    if not rows: return None
    os.makedirs(base_folder, exist_ok=True)
    out = os.path.join(base_folder, timestamp_name("export_metrics"))
    cols = list(rows[0].keys())
    with open(out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader(); w.writerows(rows)
    return out
