import yaml

def load_columns_yaml(path: str) -> list[str]:
    with open(path, "r", encoding="utf-8") as f:
        y = yaml.safe_load(f) or {}
    cols = [str(c).strip() for c in (y.get("columns") or []) if str(c).strip()]
    seen, out = set(), []
    for c in cols:
        if c not in seen:
            out.append(c); seen.add(c)
    return out
