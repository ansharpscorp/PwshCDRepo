import pyodbc
from azure.identity import ClientSecretCredential

def _aad_access_token(tenant_id: str, client_id: str, client_secret: str) -> bytes:
    scope = "https://database.windows.net/.default"
    token = ClientSecretCredential(tenant_id, client_id, client_secret).get_token(scope).token
    return bytes(token, "utf-16-le")

def connect_odbc(server: str, database: str, driver: str,
                 tenant_id: str, client_id: str, client_secret: str,
                 timeout_seconds: int = 0):
    conn_str = (
        f"Driver={driver};"
        f"Server=tcp:{server},1433;"
        f"Database={database};"
        "Encrypt=yes;TrustServerCertificate=no;"
        "Authentication=ActiveDirectoryAccessToken;"
        f"Timeout={timeout_seconds};"
    )
    token = _aad_access_token(tenant_id, client_id, client_secret)
    conn = pyodbc.connect(conn_str, attrs_before={1256: token})  # 1256 = SQL_COPT_SS_ACCESS_TOKEN
    conn.autocommit = True
    return conn
