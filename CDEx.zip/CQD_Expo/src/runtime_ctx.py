import json, os
from db import connect_odbc
from adls import get_abfs_filesystem

class RuntimeCtx:
    def __init__(self, root: str):
        with open(os.path.join(root, "settings.json"), "r", encoding="utf-8") as f:
            self.settings = json.load(f)
        with open(os.path.join(root, "config.json"), "r", encoding="utf-8") as f:
            self.config = json.load(f)

        s = self.settings["sql"]
        self.server   = s["server"]
        self.database = s["database"]
        self.driver   = s.get("odbc_driver", "{ODBC Driver 18 for SQL Server}")
        self.timeout  = int(s.get("timeout_seconds", 0))
        self.arraysize = int(s.get("arraysize", 100000))

        auth = s["aad_auth"]
        self.tenant   = auth["tenant_id"]
        self.client   = auth["client_id"]
        self.secret   = auth["client_secret"]

        a = self.settings["adls"]
        self.account  = a["account_name"]
        self.container= a["container"]

    def sql_conn(self):
        return connect_odbc(self.server, self.database, self.driver,
                            self.tenant, self.client, self.secret,
                            timeout_seconds=self.timeout)

    def adls_fs(self):
        return get_abfs_filesystem(self.account, self.tenant, self.client, self.secret)
