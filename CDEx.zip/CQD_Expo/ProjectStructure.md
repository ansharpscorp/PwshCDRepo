cqd-exporter/
├─ README.md
├─ requirements.txt
├─ settings.json
├─ config.json
├─ columns.yml
├─ sql/
│  └─ base_query.sql
└─ src/
   ├─ main.py
   ├─ parallel.py
   ├─ db.py
   ├─ adls.py
   ├─ yaml_utils.py
   ├─ export_logic.py
   ├─ logging_utils.py
   ├─ runtime_ctx.py
   └─ metrics.py
