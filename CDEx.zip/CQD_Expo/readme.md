# 1) System deps (Linux example)
sudo apt-get update
sudo apt-get install -y unixodbc unixodbc-dev  # plus MS ODBC 18 for SQL Server

# 2) Python deps
pip install -r requirements.txt

# 3) Configure settings.json + config.json + columns.yml + sql/base_query.sql

# 4) Run (per-day parallel controlled by config.json)
python -m src.main

CQD Exporter — Per-Day Parallel Parquet Export (10k Conference IDs/File)

This tool exports data from Azure Synapse Dedicated SQL Pool / Azure SQL into Parquet files on ADLS Gen2, using your original SQL (view) query. It:

Reads config from settings.json, config.json, and columns.yml

Uses your query in sql/base_query.sql (joins allowed) with @p_start / @p_end parameters

Loops day-by-day across a window

Writes to YYYY/MM/dd/part-00001.parquet, part-00002.parquet, …

Ensures each Parquet file contains all rows for exactly 10,000 unique “Conference Id” values (last file may be smaller)

Supports per-day parallelism and rotating logs

Produces a metrics CSV (rows, bytes, elapsed, file path) after the run