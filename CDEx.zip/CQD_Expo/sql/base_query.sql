/* 
  Paste your real SELECT with joins here.
  IMPORTANT: keep the WHERE to use @p_start and @p_end.
  The SELECT must include at least the columns in columns.yml,
  plus the "Date" and "Conference Id" columns (names can contain spaces).
*/
SELECT
    t.Date,
    t.[Conference Id],
    t.[Session Id],
    t.[Session Type],
    t.[First UPN],
    t.[Second UPN],
    t.[Audio Poor Stream],
    t.[Detected Network Problem],
    t.modalities,
    t.startTime,
    t.endTime
FROM dbo.TableA       t
JOIN dbo.TableB       b ON b.Key = t.Key
WHERE t.[Date] BETWEEN @p_start AND @p_end;
