using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace TeamsCdrDownloaderCs
{
    public static class TokenHelper
    {
        public static async Task<string> GetAccessToken()
        {
            var client = new HttpClient();
            var dict = new Dictionary<string, string>
            {
                {"client_id", Config.ClientId},
                {"scope", Config.Scope},
                {"client_secret", Config.ClientSecret},
                {"grant_type", "client_credentials"}
            };
            var response = await client.PostAsync(
                $"https://login.microsoftonline.com/{Config.TenantId}/oauth2/v2.0/token",
                new FormUrlEncodedContent(dict));
            var content = await response.Content.ReadAsStringAsync();
            return JObject.Parse(content)["access_token"].ToString();
        }
    }
}
