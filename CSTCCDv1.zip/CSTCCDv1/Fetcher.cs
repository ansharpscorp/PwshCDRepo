using System;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using Polly;
using Polly.Retry;
using Serilog;

namespace TeamsCdrDownloaderCs
{
    public static class Fetcher
    {
        private static AsyncRetryPolicy<HttpResponseMessage> GetRetryPolicy() => Policy
            .HandleResult<HttpResponseMessage>(r => !r.IsSuccessStatusCode)
            .WaitAndRetryAsync(5, attempt => TimeSpan.FromSeconds(Math.Pow(2, attempt)),
                (result, time, retryCount, context) => Log.Warning($"Retry {retryCount} after {time.TotalSeconds}s due to {result.Result.StatusCode}"));

        public static async Task<JArray> FetchCallRecordsAsync(string token, string startIso, string endIso)
        {
            var client = new HttpClient();
            client.DefaultRequestHeaders.Add("Authorization", $"Bearer {token}");
            var url = $"{Config.GraphUrl}?$filter=startDateTime ge {startIso} and startDateTime lt {endIso}";

            var allRecords = new JArray();
            while (!string.IsNullOrEmpty(url))
            {
                var response = await GetRetryPolicy().ExecuteAsync(() => client.GetAsync(url));
                var content = await response.Content.ReadAsStringAsync();
                var json = JObject.Parse(content);
                var values = (JArray)json["value"];
                foreach (var item in values) allRecords.Add(item);
                url = json["@odata.nextLink"]?.ToString();
            }

            return allRecords;
        }

        public static async Task ProcessRecordAsync(string token, JToken rec, DateTime date)
        {
            var id = rec["id"].ToString();
            var folderPath = Path.Combine(Config.OutputRoot, date.ToString("yyyy"), date.ToString("MM"), date.ToString("dd"));
            Directory.CreateDirectory(folderPath);

            var filePath = Path.Combine(folderPath, $"{id}.json");
            if (File.Exists(filePath))
            {
                Log.Information($"Skipping existing file {filePath}");
                return;
            }

            try
            {
                var sessions = await ExpandDataAsync(token, id, "sessions?$expand=segments");
                var participants = await ExpandDataAsync(token, id, "participants_v2");

                var result = new JObject
                {
                    ["endDateTime"] = rec["endDateTime"],
                    ["id"] = rec["id"],
                    ["joinWebUrl"] = rec["joinWebUrl"],
                    ["lastModifiedDateTime"] = rec["lastModifiedDateTime"],
                    ["modalities"] = rec["modalities"],
                    ["organizer"] = rec["organizer"],
                    ["participants"] = rec["participants"],
                    ["startDateTime"] = rec["startDateTime"],
                    ["type"] = rec["type"],
                    ["version"] = rec["version"],
                    ["participants_v2"] = participants,
                    ["sessions"] = sessions
                };

                await File.WriteAllTextAsync(filePath, result.ToString());
            }
            catch (Exception ex)
            {
                Log.Error($"Failed processing record {id}: {ex.Message}");
            }
        }

        private static async Task<JArray> ExpandDataAsync(string token, string id, string endpoint)
        {
            var client = new HttpClient();
            client.DefaultRequestHeaders.Add("Authorization", $"Bearer {token}");
            var url = $"{Config.GraphUrl}/{id}/{endpoint}";
            var allData = new JArray();

            while (!string.IsNullOrEmpty(url))
            {
                var response = await GetRetryPolicy().ExecuteAsync(() => client.GetAsync(url));
                var content = await response.Content.ReadAsStringAsync();
                var json = JObject.Parse(content);
                var values = (JArray)json["value"];
                foreach (var item in values) allData.Add(item);
                url = json["@odata.nextLink"]?.ToString();
            }

            return allData;
        }
    }
}
