using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Serilog;

namespace TeamsCdrDownloaderCs
{
    public class DayProcessor
    {
        private readonly string _token;
        public DayProcessor(string token) => _token = token;

        public async Task ProcessDayAsync(string dateStr, int startHour, int endHour)
        {
            var date = DateTime.Parse(dateStr);
            var tasks = new List<Task>();
            SemaphoreSlim throttler = new SemaphoreSlim(4);

            int startInterval = (startHour * 60) / 15;
            int endInterval = (endHour * 60) / 15;

            for (int i = startInterval; i < endInterval; i++)
            {
                var start = date.AddMinutes(15 * i);
                var end = start.AddMinutes(15);
                var startIso = start.ToString("yyyy-MM-ddTHH:mm:ssZ");
                var endIso = end.ToString("yyyy-MM-ddTHH:mm:ssZ");

                await throttler.WaitAsync();
                tasks.Add(Task.Run(async () =>
                {
                    try
                    {
                        await ProcessIntervalAsync(date, startIso, endIso);
                    }
                    finally
                    {
                        throttler.Release();
                    }
                }));
            }

            await Task.WhenAll(tasks);
        }

        private async Task ProcessIntervalAsync(DateTime date, string startIso, string endIso)
        {
            try
            {
                var records = await Fetcher.FetchCallRecordsAsync(_token, startIso, endIso);
                foreach (var rec in records)
                {
                    await Fetcher.ProcessRecordAsync(_token, rec, date);
                }
            }
            catch (Exception ex)
            {
                Log.Error($"Interval processing failed {startIso}-{endIso}: {ex.Message}");
            }
        }
    }
}
