using System;
using Serilog;
using System.Threading.Tasks;

namespace TeamsCdrDownloaderCs
{
    public class Program
    {
        static async Task Main(string[] args)
        {
            if (args.Length < 3)
            {
                Console.WriteLine("Usage: TeamsCdrDownloaderCs <date> <startHour> <endHour>");
                return;
            }

            Log.Logger = new LoggerConfiguration()
                .WriteTo.File("log.txt")
                .CreateLogger();

            Log.Information("Starting Teams CDR Downloader...");

            var token = await TokenHelper.GetAccessToken();
            var processor = new DayProcessor(token);

            string dateArg = args[0];
            int startHour = int.Parse(args[1]);
            int endHour = int.Parse(args[2]);

            await processor.ProcessDayAsync(dateArg, startHour, endHour);
        }
    }
}
