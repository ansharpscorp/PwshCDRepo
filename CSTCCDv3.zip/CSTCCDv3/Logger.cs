//------------------------ Logger.cs ------------------------
using Serilog;

namespace TeamsCdrDownloaderCsFinal
{
    public static class Logger
    {
        public static void Init()
        {
            Log.Logger = new LoggerConfiguration()
                .WriteTo.File("log.txt")
                .CreateLogger();
        }
    }
}
