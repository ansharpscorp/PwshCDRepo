//------------------------ Program.cs ------------------------
using Serilog;
using System;
using System.Threading.Tasks;

namespace TeamsCdrDownloaderCsFinal
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            if (args.Length < 3)
            {
                Console.WriteLine("Usage: TeamsCdrDownloaderCsFinal <date> <startHour> <endHour>");
                return;
            }

            Logger.Init();
            Log.Information("Starting CDR Downloader");

            string token = await TokenHelper.GetAccessToken();
            var processor = new DayProcessor(token);

            string dateArg = args[0];
            int startHour = int.Parse(args[1]);
            int endHour = int.Parse(args[2]);

            await processor.ProcessDayAsync(dateArg, startHour, endHour);
            Log.Information("CDR Download complete.");
        }
    }
}
