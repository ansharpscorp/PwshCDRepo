//------------------------ DayProcessor.cs ------------------------
using Newtonsoft.Json.Linq;
using Serilog;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace TeamsCdrDownloaderCsFinal
{
    public class DayProcessor
    {
        private readonly string _token;
        public DayProcessor(string token) => _token = token;

        public async Task ProcessDayAsync(string dateStr, int startHour, int endHour)
        {
            var date = DateTime.Parse(dateStr);
            var tasks = new List<Task>();
            using SemaphoreSlim throttler = new SemaphoreSlim(Config.MaxParallelism);

            int startInterval = (startHour * 60) / 15;
            int endInterval = (endHour * 60) / 15;

            for (int i = startInterval; i < endInterval; i++)
            {
                var start = date.AddMinutes(15 * i);
                var end = start.AddMinutes(15);
                var startIso = start.ToString("yyyy-MM-ddTHH:mm:ssZ");
                var endIso = end.ToString("yyyy-MM-ddTHH:mm:ssZ");

                await throttler.WaitAsync();
                tasks.Add(Task.Run(async () =>
                {
                    try
                    {
                        var records = await Fetcher.FetchCallRecordsAsync(_token, startIso, endIso);
                        var recordTasks = new List<Task>();
                        foreach (var rec in records)
                        {
                            recordTasks.Add(Fetcher.ProcessRecordAsync(_token, rec, date));
                        }
                        await Task.WhenAll(recordTasks);
                    }
                    finally
                    {
                        throttler.Release();
                    }
                }));
            }
            await Task.WhenAll(tasks);
        }
    }
}
