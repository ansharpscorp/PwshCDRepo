//------------------------ Config.cs ------------------------
using System;

namespace TeamsCdrDownloaderCsFinal
{
    public static class Config
    {
        public static string TenantId = "<your-tenant-id>";
        public static string ClientId = "<your-client-id>";
        public static string ClientSecret = "<your-client-secret>";
        public static string Scope = "https://graph.microsoft.com/.default";
        public static string GraphUrl = "https://graph.microsoft.com/v1.0/communications/callRecords";
        public static string OutputRoot = "_cdrjsons";
        public static string FailedCsv = "failed_records.csv";
        public static int MaxParallelism = 8; // adjustable as per CPU (4-core can handle 8 logical threads)
    }
}