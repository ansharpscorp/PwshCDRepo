//------------------------ Fetcher.cs ------------------------
using Newtonsoft.Json.Linq;
using Polly;
using Polly.Retry;
using Serilog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;

namespace TeamsCdrDownloaderCsFinal
{
    public static class Fetcher
    {
        private static readonly AsyncRetryPolicy<HttpResponseMessage> RetryPolicy = Policy
            .HandleResult<HttpResponseMessage>(r => !r.IsSuccessStatusCode)
            .WaitAndRetryAsync(5, attempt => TimeSpan.FromSeconds(Math.Pow(2, attempt)),
                (result, time, retryCount, context) =>
                    Log.Warning($"Retry {retryCount}: {result.Result.StatusCode}"));

        public static async Task<JArray> FetchCallRecordsAsync(string token, string startIso, string endIso)
        {
            using var client = new HttpClient();
            client.DefaultRequestHeaders.Add("Authorization", $"Bearer {token}");
            var url = $"{Config.GraphUrl}?$filter=startDateTime ge {startIso} and startDateTime lt {endIso}";
            var allRecords = new JArray();
            while (!string.IsNullOrEmpty(url))
            {
                var response = await RetryPolicy.ExecuteAsync(() => client.GetAsync(url));
                var json = JObject.Parse(await response.Content.ReadAsStringAsync());
                var values = (JArray?)json["value"] ?? new JArray();
                allRecords.Merge(values);
                url = json["@odata.nextLink"]?.ToString();
            }
            return allRecords;
        }

        public static async Task ProcessRecordAsync(string token, JToken rec, DateTime date)
        {
            var id = rec["id"]?.ToString();
            if (string.IsNullOrEmpty(id)) return;
            var folderPath = Path.Combine(Config.OutputRoot, date.ToString("yyyy"), date.ToString("MM"), date.ToString("dd"));
            Directory.CreateDirectory(folderPath);
            var filePath = Path.Combine(folderPath, $"{id}.json");
            if (File.Exists(filePath)) return;

            try
            {
                var sessions = await ExpandDataAsync(token, id, "sessions?$expand=segments");
                var participants = await ExpandDataAsync(token, id, "participants_v2");
                var result = new JObject
                {
                    ["endDateTime"] = rec["endDateTime"],
                    ["id"] = rec["id"],
                    ["joinWebUrl"] = rec["joinWebUrl"],
                    ["lastModifiedDateTime"] = rec["lastModifiedDateTime"],
                    ["modalities"] = rec["modalities"],
                    ["organizer"] = rec["organizer"],
                    ["participants"] = rec["participants"],
                    ["startDateTime"] = rec["startDateTime"],
                    ["type"] = rec["type"],
                    ["version"] = rec["version"],
                    ["participants_v2"] = participants,
                    ["sessions"] = sessions
                };
                await File.WriteAllTextAsync(filePath, result.ToString());
            }
            catch (Exception ex)
            {
                Log.Error($"Failed processing {id}: {ex.Message}");
                await File.AppendAllTextAsync(Config.FailedCsv, $"{id},{date}\n");
            }
        }

        private static async Task<JArray> ExpandDataAsync(string token, string id, string endpoint)
        {
            using var client = new HttpClient();
            client.DefaultRequestHeaders.Add("Authorization", $"Bearer {token}");
            var url = $"{Config.GraphUrl}/{id}/{endpoint}";
            var allData = new JArray();
            while (!string.IsNullOrEmpty(url))
            {
                var response = await RetryPolicy.ExecuteAsync(() => client.GetAsync(url));
                var json = JObject.Parse(await response.Content.ReadAsStringAsync());
                var values = (JArray?)json["value"] ?? new JArray();
                allData.Merge(values);
                url = json["@odata.nextLink"]?.ToString();
            }
            return allData;
        }
    }
}