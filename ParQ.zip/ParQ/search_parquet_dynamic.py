#!/usr/bin/env python3
"""
Search ADLS Gen2 Parquet partitions laid out as base/Year/Month/Day/*.parquet,
with dates determined dynamically (latest, range, or all with a cap).

Requires:
  pip install "adlfs>=2024.4.0" "pyarrow>=14.0.0" "pandas>=2.1.0" "python-dateutil>=2.9.0"
"""
import json
import sys
from pathlib import Path
from datetime import datetime, date
from typing import Dict, List, Tuple, Iterable
from collections import defaultdict

import fsspec
import pandas as pd
import pyarrow as pa
import pyarrow.dataset as ds
from dateutil.parser import isoparse

# ----------------------------- utilities -----------------------------
def load_settings(path: Path) -> Dict:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)

def get_fs(account_name: str, account_key: str):
    return fsspec.filesystem("abfs", account_name=account_name, account_key=account_key)

def path_parts(p: str) -> List[str]:
    # normalize split across abfs:// URLs
    return p.replace("abfs://", "").split("/")

def collect_files_by_date(fs, container: str, base_path: str, recursive: bool) -> Dict[date, List[str]]:
    """
    Scan for parquet files under abfs://container/base_path/** and bucket them by YYYY/MM/dd.
    """
    pattern = f"abfs://{container}/{base_path}/**/*.parquet" if recursive else f"abfs://{container}/{base_path}/*.parquet"
    all_files = fs.glob(pattern)
    buckets: Dict[date, List[str]] = defaultdict(list)

    for p in all_files:
        parts = path_parts(p)
        # Expect parts like: [container, base, YYYY, MM, dd, file.parquet]
        try:
            idx = parts.index(base_path)
        except ValueError:
            # base_path might be nested; try to find it as a segment
            # fallback: search candidate triplets that look like YYYY/MM/dd
            idx = None
            for i in range(1, len(parts)-3):
                y, m, d = parts[i], parts[i+1], parts[i+2]
                if len(y) == 4 and y.isdigit() and len(m) in (1,2) and len(d) in (1,2):
                    try:
                        dt = date(int(y), int(m), int(d))
                        buckets[dt].append(p)
                        idx = -1
                        break
                    except Exception:
                        pass
            if idx is None:
                continue
            elif idx == -1:
                continue

        # extract y/m/d relative to base_path
        try:
            y, m, d = parts[idx+1], parts[idx+2], parts[idx+3]
            dt = date(int(y), int(m), int(d))
            buckets[dt].append(p)
        except Exception:
            # not a dated partition
            continue

    return buckets

def select_dates(buckets: Dict[date, List[str]], mode: str, start_date: str=None, end_date: str=None, max_dates: int=5) -> List[date]:
    if not buckets:
        return []
    all_dates = sorted(buckets.keys())
    if mode == "latest":
        return [max(all_dates)]
    elif mode == "range":
        if not start_date or not end_date:
            raise ValueError("mode 'range' requires start_date and end_date (YYYY-MM-DD).")
        start = isoparse(start_date).date()
        end = isoparse(end_date).date()
        return [d for d in all_dates if start <= d <= end]
    elif mode == "all":
        # most recent N by default
        return sorted(all_dates, reverse=True)[:max_dates]
    else:
        raise ValueError("mode must be one of: latest | range | all")

def dataset_from_files(fs, files: List[str]) -> ds.Dataset:
    return ds.dataset(files, format="parquet", filesystem=fs)

def print_schema(dataset: ds.Dataset):
    schema: pa.Schema = dataset.schema
    print("\n=== Schema (pyarrow) ===")
    for field in schema:
        print(f"- {field.name}: {field.type}")

def sample_rows(files: List[str], n: int, storage_options: Dict) -> pd.DataFrame:
    rows_remaining = n
    dfs = []
    for p in files:
        if rows_remaining <= 0:
            break
        try:
            df = pd.read_parquet(p, storage_options=storage_options)
        except Exception as e:
            print(f"[WARN] Could not read {p}: {e}")
            continue
        if df.empty:
            continue
        if len(df) > rows_remaining:
            df = df.head(rows_remaining)
        dfs.append(df)
        rows_remaining -= len(df)
    if not dfs:
        return pd.DataFrame()
    return pd.concat(dfs, ignore_index=True)

# ----------------------------- main -----------------------------
def main():
    cfg = load_settings(Path(__file__).with_name("settings.json"))
    account_name = cfg["storage_account_name"]
    account_key = cfg["storage_account_key"]
    container = cfg["container_name"]
    base_path = cfg["base_path"].strip("/")
    mode = cfg.get("mode", "latest")
    start_date = cfg.get("start_date")
    end_date = cfg.get("end_date")
    max_dates = int(cfg.get("max_dates", 5))
    sample_n = int(cfg.get("sample_rows", 20))
    recursive = bool(cfg.get("recursive", True))

    fs = get_fs(account_name, account_key)
    storage_options = {"account_name": account_name, "account_key": account_key}

    # Discover files grouped by dates
    buckets = collect_files_by_date(fs, container, base_path, recursive)
    if not buckets:
        print(f"No parquet files found under abfs://{container}/{base_path}{'/**' if recursive else ''}")
        sys.exit(2)

    dates = select_dates(buckets, mode, start_date, end_date, max_dates)
    if not dates:
        print("No dates selected based on the current mode/filter. Check your settings.")
        sys.exit(3)

    print("Selected date partitions:")
    for d in sorted(dates):
        print(f"  - {d.isoformat()} ({len(buckets[d])} file(s))")

    # Flatten file list for selected dates
    selected_files: List[str] = []
    for d in dates:
        selected_files.extend(buckets[d])

    # Show a few example paths
    print("\nExample file(s):")
    for p in selected_files[:5]:
        print(f"  - {p}")

    # Build a dataset and show schema
    try:
        dataset = dataset_from_files(fs, selected_files)
        print_schema(dataset)
    except Exception as e:
        print(f"\n[WARN] Could not create dataset from files: {e}")

    # Show pandas dtypes too (helpful for users familiar with pandas)
    try:
        df_preview = sample_rows(selected_files, sample_n, storage_options)
        if df_preview.empty:
            print("\nNo visible rows in the selected files.")
        else:
            print("\n=== Schema (pandas dtypes) ===")
            width = max(len(c) for c in df_preview.columns)
            for c, t in df_preview.dtypes.items():
                print(f"- {c.ljust(width)} : {t}")
            print("\n=== Sample Rows ===")
            with pd.option_context("display.max_columns", None, "display.width", 220):
                print(df_preview.to_string(index=False))
    except Exception as e:
        print(f"\n[WARN] Could not read sample rows: {e}")

if __name__ == "__main__":
    main()
