How it works

Scans abfs://<container>/<base_path>/**/*.parquet

Buckets files by detected date partition (YYYY/MM/dd)

Selects dates based on mode:

"latest" → most recent date only (default)

"range" → use start_date and end_date (YYYY-MM-DD)

"all" → most recent max_dates

Prints an Arrow schema and pandas dtypes

Shows sample rows (configurable)