callrecord-parquet/
├─ config/
│  ├─ secrets.json
│  ├─ settings.json
│  └─ columns.json
├─ src/
│  ├─ main.py
│  ├─ io_utils.py
│  ├─ flattener.py
│  ├─ writer.py
│  ├─ logger.py
│  └─ date_utils.py
├─ requirements.txt
└─ README.md
