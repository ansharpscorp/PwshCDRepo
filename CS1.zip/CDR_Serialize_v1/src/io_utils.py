from typing import List
import json
import fsspec
from .logger import info

def load_json(path: str):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def get_fs(secrets: dict):
    mode = (secrets.get("auth_mode") or "local").lower()
    if mode == "local":
        return fsspec.filesystem("file")
    elif mode == "abfss":
        return fsspec.filesystem(
            "abfss",
            account_name=secrets["account_name"],
            tenant_id=secrets["tenant_id"],
            client_id=secrets["client_id"],
            client_secret=secrets["client_secret"],
        )
    else:
        raise ValueError(f"Unknown auth_mode: {mode}")

def list_json_files(fs, folder_uri: str) -> List[str]:
    pattern = folder_uri.rstrip("/") + "/*.json"
    entries = fs.glob(pattern)
    files = [p for p in entries if not fs.isdir(p)]
    files.sort()
    info("Listed files", folder=folder_uri, count=len(files))
    return files

def join_uri(root: str, *parts: str) -> str:
    base = root.rstrip("/")
    tail = "/".join(p.strip("/") for p in parts)
    return f"{base}/{tail}"

def ensure_dir(fs, dir_uri: str):
    try:
        fs.makedirs(dir_uri, exist_ok=True)
    except Exception:
        pass
