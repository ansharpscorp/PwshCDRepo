from datetime import date, timedelta

MMM = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]

def ymd_range(start: date, end: date):
    d = start
    while d <= end:
        yield d
        d += timedelta(days=1)

def to_folder_parts(d: date):
    return MMM[d.month-1], f"{d.day:02d}"

def is_weekend(d: date):
    return d.weekday() >= 5
