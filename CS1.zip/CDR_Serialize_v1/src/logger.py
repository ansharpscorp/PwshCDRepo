import sys, json, time

def log(level, msg, **kv):
    payload = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "level": level, "msg": msg}
    if kv: payload.update(kv)
    print(json.dumps(payload, ensure_ascii=False), file=sys.stderr)

def info(msg, **kv):  log("INFO", msg, **kv)
def warn(msg, **kv):  log("WARN", msg, **kv)
def err(msg, **kv):   log("ERROR", msg, **kv)
