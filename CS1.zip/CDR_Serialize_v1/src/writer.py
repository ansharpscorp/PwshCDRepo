from typing import Dict, List, Optional, Union
import pyarrow as pa
import pyarrow.parquet as pq
from .logger import info
from .io_utils import ensure_dir, join_uri

ColumnSpec = Union[str, Dict[str, object]]

class CallRecordShardWriter:
    """
    Shards by call record count. Keeps only configured columns (order preserved).
    Supports column specs:
      - "colName"
      - {"name": "NewName", "from": "Existing"}
      - {"name": "AnyId", "coalesce": ["a","b"], "default": null}
    """

    def __init__(self, fs_out, out_day_dir_uri: str,
                 callrecords_per_file: int = 50000,
                 row_group_size: int = 10000,
                 compression: str = "snappy",
                 columns: Optional[List[ColumnSpec]] = None):
        self.fs_out = fs_out
        self.out_day_dir = out_day_dir_uri.rstrip("/")
        ensure_dir(self.fs_out, self.out_day_dir)

        self.callrecords_per_file = max(int(callrecords_per_file), 1)
        self.row_group_size = int(row_group_size)
        self.compression = compression
        self.columns = columns

        self.buffer: List[Dict] = []
        self.call_count = 0
        self.file_index = 0

    def _next_outfile(self) -> str:
        self.file_index += 1
        return join_uri(self.out_day_dir, f"part-{self.file_index:05d}.parquet")

    def _apply_column_spec(self, row: Dict, spec: ColumnSpec) -> Dict:
        if isinstance(spec, str):
            return {spec: row.get(spec)}
        name = spec.get("name")
        if "from" in spec:
            return {name: row.get(spec["from"])}
        if "coalesce" in spec:
            for key in spec["coalesce"]:
                val = row.get(key)
                if val is not None:
                    return {name: val}
            return {name: spec.get("default")}
        return {str(name) if name else "unnamed": None}

    def _filter_columns(self, rows: List[Dict]) -> List[Dict]:
        if not self.columns:
            return rows
        out_rows: List[Dict] = []
        for r in rows:
            new_r: Dict = {}
            for spec in self.columns:
                new_r.update(self._apply_column_spec(r, spec))
            out_rows.append(new_r)
        return out_rows

    def _write_shard(self):
        if not self.buffer:
            return 0, 0
        outfile = self._next_outfile()
        rows = self._filter_columns(self.buffer)
        table = pa.Table.from_pylist(rows)

        with self.fs_out.open(outfile, "wb") as f:
            pq.write_table(table, f,
                           compression=self.compression,
                           row_group_size=self.row_group_size)

        rows_n = len(rows)
        calls_n = self.call_count
        info("Wrote shard", file=outfile, rows=rows_n, callrecords=calls_n)

        self.buffer.clear()
        self.call_count = 0
        return rows_n, calls_n

    def add_callrecord(self, rows_for_record: List[Dict]):
        self.buffer.extend(rows_for_record)
        self.call_count += 1
        if self.call_count >= self.callrecords_per_file:
            return self._write_shard()
        return 0, 0

    def flush(self):
        return self._write_shard()
