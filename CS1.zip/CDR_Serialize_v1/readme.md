# Call Record JSON → Parquet (Config-Driven Columns)

## Features
- Weekday sharding: 50,000 call records per file
- Weekend: single file (or configurable)
- Column selection via `config/columns.json`
- Supports local or AD
