import argparse, asyncio, json, yaml, pandas as pd, multiprocessing
from concurrent.futures import ProcessPoolExecutor, as_completed
from sqlalchemy import create_engine
from tqdm import tqdm
from io_handler_async import upload_all_async
from utils import generate_date_range
from logger import get_logger
from processor import enrich_call_data, init_lookups

# --- helper: SQL connection ---
def get_sql_engine(cfg):
    db = cfg["database"]
    conn = f"mssql+pyodbc://{db['username']}:{db['password']}@{db['server']}/{db['database']}?driver={db['driver']}"
    return create_engine(conn, fast_executemany=True)

# --- helper: safe SQL read ---
def read_sql(engine, sql, chunksize=None):
    try:
        return pd.read_sql(sql, engine, chunksize=chunksize)
    except Exception as e:
        print(f"❌ SQL read failed: {e}")
        return pd.DataFrame()

# --- worker for parallel chunk processing ---
def process_chunk(df):
    return enrich_call_data(df)

# --- async uploader ---
async def upload_one_day(final_df, cfg, date_str, log):
    if final_df is None or final_df.empty:
        log.warning(f"⚠️ No rows to upload for {date_str}")
        return
    await upload_all_async([{"df": final_df, "cfg": cfg, "date_str": date_str, "logger": log}],
                           concurrency=cfg.get("upload_concurrency", 5))

# --- main orchestrator ---
def main(start, end):
    log = get_logger()
    print("🚀 Starting Teams Call Data Processing...")

    # --- Load config ---
    with open("config.json") as f:
        cfg = json.load(f)
    with open("columns.yml") as f:
        cols_cfg = yaml.safe_load(f) or {}

    call_cols = cols_cfg.get("call_data_columns", [])
    user_cols = cols_cfg.get("user_data_columns", [])
    net_cols = cols_cfg.get("network_data_columns", [])

    if not call_cols:
        raise ValueError("❌ call_data_columns missing in columns.yml")

    eng = get_sql_engine(cfg)
    print("✅ Database connection established successfully.")

    # --- Load User and Network Tables ---
    user_sql = f"SELECT {', '.join(user_cols) if user_cols else '*'} FROM {cfg['tables']['user_data']}"
    net_sql = f"SELECT {', '.join(net_cols) if net_cols else '*'} FROM {cfg['tables']['network_data']}"
    user_df = read_sql(eng, user_sql)
    net_df = read_sql(eng, net_sql)

    if user_df.empty or net_df.empty:
        raise ValueError("❌ User or Network table returned empty. Check columns.yml definitions or table names.")

    print(f"📥 Loaded user ({len(user_df)}) and network ({len(net_df)}) rows.")

    # --- Date range ---
    dates = generate_date_range(start, end)

    for d in dates:
        print(f"\n📅 === Processing {d} ===")
        cols_str = ", ".join(call_cols)
        sql = f"""
        SELECT {cols_str}
        FROM {cfg['tables']['call_data']}
        WHERE CONVERT(date, [{cfg['date_column']}]) = '{pd.to_datetime(d).strftime('%Y-%m-%d')}'
        """
        chunks = list(read_sql(eng, sql, chunksize=int(cfg.get("sql_chunksize", 100000))))

        if not chunks:
            print(f"⚠️ No data found for {d}, skipping.")
            continue

        total_rows = sum(len(c) for c in chunks)
        print(f"📦 Loaded {total_rows:,} rows across {len(chunks)} chunks.")

        workers = max(1, multiprocessing.cpu_count() - 1) \
            if str(cfg.get("chunk_workers", "max")).lower() == "max" else int(cfg["chunk_workers"])
        print(f"🧩 Using {workers} workers for enrichment.")

        enriched_parts = []
        with ProcessPoolExecutor(max_workers=workers, initializer=init_lookups, initargs=(user_df, net_df)) as ex:
            futs = [ex.submit(process_chunk, c) for c in chunks]
            for f in tqdm(as_completed(futs), total=len(futs), desc=f"Processing {d}"):
                try:
                    enriched_parts.append(f.result())
                except Exception as e:
                    log.error(f"❌ Chunk failed on {d}: {e}")

        if not enriched_parts:
            print(f"⚠️ No enriched data for {d}.")
            continue

        final_df = pd.concat(enriched_parts, ignore_index=True)
        print(f"✅ {d} processed successfully ({len(final_df):,} rows).")

        asyncio.run(upload_one_day(final_df, cfg, d, log))
        print(f"☁️ {d} uploaded.")

    print("\n🏁 All dates processed successfully.")

# --- CLI entry ---
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Teams Call to Parquet Processor")
    parser.add_argument("--startDate", required=True, help="YYYY-MM-DD")
    parser.add_argument("--endDate", required=True, help="YYYY-MM-DD")
    args = parser.parse_args()
    main(args.startDate, args.endDate)
