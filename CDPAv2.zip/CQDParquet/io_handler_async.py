import io, asyncio
from azure.storage.blob.aio import BlobServiceClient
from azure.core.exceptions import AzureError
from tqdm.asyncio import tqdm_asyncio

async def upload_to_adls_async(df, cfg, date_str, logger, sem):
    adls = cfg["adls"]
    year, month = date_str[:4], date_str[4:6]
    file_name = f"Parquet_{date_str}.parquet"
    blob_path = f"{adls['folder']}/{year}/{month}/{file_name}"

    try:
        buf = io.BytesIO()
        df.to_parquet(buf, index=False, engine="pyarrow", compression="snappy")
        buf.seek(0)

        async with sem:
            async with BlobServiceClient(
                f"https://{adls['account_name']}.blob.core.windows.net",
                credential=adls["account_key"]
            ) as svc:
                client = svc.get_blob_client(adls["container"], blob_path)
                await client.upload_blob(buf.getvalue(), overwrite=True)

        logger.info(f"✅ Uploaded (async): {blob_path} ({len(df)} rows)")
        return True
    except (AzureError, Exception) as e:
        logger.error(f"❌ Upload failed {blob_path}: {e}")
        return False

async def upload_all_async(tasks, concurrency=5):
    sem = asyncio.Semaphore(concurrency)
    async def run(t): return await upload_to_adls_async(**t, sem=sem)
    return await tqdm_asyncio.gather(*(run(t) for t in tasks),
                                     total=len(tasks),
                                     desc="Uploading to ADLS")
