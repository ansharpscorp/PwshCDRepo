import pandas as pd, numpy as np, re
from collections import Counter

_LOOKUPS = {"user_df": None, "network_df": None}

def init_lookups(user_df, network_df):
    _LOOKUPS["user_df"] = user_df
    _LOOKUPS["network_df"] = network_df

def most_common(s):
    vals = [v for v in s.dropna()]
    return Counter(vals).most_common(1)[0][0] if vals else None

def enrich_call_data(call_df, user_df=None, network_df=None):
    if user_df is None: user_df = _LOOKUPS["user_df"]
    if network_df is None: network_df = _LOOKUPS["network_df"]

    df = call_df.copy()
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    user_emails = set(user_df["EmailAddress"].dropna().unique())

    # ----- Call / participant type -----
    def call_type(r):
        st = r.get("Session Type")
        if st == "P2P":
            if r.get("First UserType") == "User" and bool(r.get("First Is Caller")) and r.get("First UPN") in user_emails:
                return "Outbound"
            if r.get("Second UPN") in user_emails:
                return "Inbound"
            if pd.isna(r.get("First UPN")) and pd.notna(r.get("First Phone Number")) and r.get("Second UPN") in user_emails:
                return "Inbound"
            if pd.isna(r.get("Second UPN")) and pd.notna(r.get("Second Phone Number")) and r.get("First UPN") in user_emails:
                return "Outbound"
        elif st == "Conf" and pd.isna(r.get("Second UPN")) and pd.notna(r.get("Second Phone Number")):
            return "Conference"
        return None

    def participant_type(r):
        st = r.get("Session Type")
        if st == "Conf":
            if pd.isna(r.get("Second UPN")) and pd.notna(r.get("Second Phone Number")):
                return "External"
            return "Internal"
        elif st == "P2P":
            if (pd.isna(r.get("First UPN")) and pd.notna(r.get("First Phone Number"))) or \
               (pd.isna(r.get("Second UPN")) and pd.notna(r.get("Second Phone Number"))):
                return "External"
            return "Internal"
        return None

    df["Call Type"] = df.apply(call_type, axis=1)
    df["Participant Type"] = df.apply(participant_type, axis=1)

    # ----- Detect First/Second pairs -----
    first_cols = [c for c in df.columns if c.lower().startswith("first ")]
    second_cols = [c for c in df.columns if c.lower().startswith("second ")]
    pair_map = {}
    for fc in first_cols:
        base = re.sub(r"^first\s+", "", fc, flags=re.I)
        sc = next((s for s in second_cols if s.lower().endswith(base.lower())), None)
        if sc: pair_map[base] = (fc, sc)

    # ----- Choose correct side -----
    def side_selector(r):
        st = r.get("Session Type")
        if st == "P2P":
            use_first = ((r.get("First UserType") == "User" and bool(r.get("First Is Caller")) and r.get("First UPN") in user_emails)
                         or (pd.isna(r.get("Second UPN")) and r.get("First UPN") in user_emails))
        elif st == "Conf": use_first = False
        else: use_first = True
        sel = {}
        for base, (fc, sc) in pair_map.items():
            sel[base] = r.get(fc) if use_first else r.get(sc)
        return pd.Series(sel)

    side_df = df.apply(side_selector, axis=1)
    df = pd.concat([df, side_df], axis=1)

    # ----- Network enrichment -----
    def subnet_match(r):
        subnet = r.get("Reflexive Local IP Network")
        if subnet in set(network_df["Address"].dropna().unique()):
            m = network_df.loc[network_df["Address"] == subnet].iloc[0]
            return pd.Series({"Subnet Type":"Office",
                              "Subnet Building":m.get("Building"),
                              "Subnet Country":m.get("Country")})
        return pd.Series({"Subnet Type":"Unknown",
                          "Subnet Building":None,"Subnet Country":None})
    net_df = df.apply(subnet_match, axis=1)
    df = pd.concat([df, net_df], axis=1)

    # ----- Aggregations -----
    num_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    agg = {c:("sum" if any(k in c.lower() for k in ["count","sum","stream"]) else "max") for c in num_cols}
    keys = ["Conference Id","Session Type","Call Type","Participant Type",
            "Subnet Type","Subnet Building","Subnet Country"]
    agg_df = df.groupby(keys, observed=True, sort=False).agg(agg).reset_index()

    str_fields = list(pair_map.keys()) + ["Reflexive Local IP Network"]
    def collapse(g):
        return pd.Series({c:most_common(g[c]) for c in str_fields if c in g})
    s_df = df.groupby(keys).apply(collapse).reset_index()
    agg_df = pd.merge(agg_df, s_df, on=keys, how="left")

    agg_df["Total Participants"] = df.groupby("Conference Id")["Conference Id"].transform("count").values
    result = agg_df.merge(user_df, how="cross")

    meta = ["EmailAddress","DisplayName","XXXX_SECT_XXX",
            "Conference Id","Session Type","Call Type","Participant Type",
            "Total Participants","Subnet Type","Subnet Building","Subnet Country"]
    out = meta + [c for c in agg_df.columns if c not in meta]
    return result.loc[:, [c for c in out if c in result.columns]]
