// appsettings.json
{
  "Graph": {
    "TenantId": "<Your-Tenant-Id>",
    "ClientId": "<Your-Client-Id>",
    "ClientSecret": "<Your-Client-Secret>"
  },
  "Paths": {
    "InputCsvPath": "ConferenceIds_20250612.csv",
    "OutputFolder": "JsonOutput",
    "ErrorCsvPath": "FailedConferenceIds.csv"
  },
  "Logging": {
    "LogFilePath": "expand_log.txt"
  }
}

// Program.cs
using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Serilog;

namespace TeamsGraphApiExpander
{
    class Program
    {
        static async Task Main(string[] args)
        {
            IConfiguration config = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false)
                .Build();

            Log.Logger = new LoggerConfiguration()
                .WriteTo.Console()
                .WriteTo.File(config["Logging:LogFilePath"], rollingInterval: RollingInterval.Day)
                .CreateLogger();

            var graphHelper = new GraphHelper(config);
            var processor = new ConferenceProcessor(graphHelper, config);
            await processor.ProcessConferenceIdsAsync();

            Log.CloseAndFlush();
        }
    }
}

// GraphHelper.cs
using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Identity.Client;

namespace TeamsGraphApiExpander
{
    public class GraphHelper
    {
        private string tenantId, clientId, clientSecret;
        private IConfidentialClientApplication app;
        private string[] scopes = new[] { "https://graph.microsoft.com/.default" };

        public GraphHelper(IConfiguration config)
        {
            tenantId = config["Graph:TenantId"];
            clientId = config["Graph:ClientId"];
            clientSecret = config["Graph:ClientSecret"];

            app = ConfidentialClientApplicationBuilder.Create(clientId)
                .WithClientSecret(clientSecret)
                .WithAuthority(new Uri($"https://login.microsoftonline.com/{tenantId}"))
                .Build();
        }

        public async Task<string> GetAccessTokenAsync(bool forceRefresh = false)
        {
            var result = await app.AcquireTokenForClient(scopes)
                .WithForceRefresh(forceRefresh)
                .ExecuteAsync();
            return result.AccessToken;
        }
    }
}

// ConferenceProcessor.cs
using System;
using System.Collections.Concurrent;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Serilog;

namespace TeamsGraphApiExpander
{
    public class ConferenceProcessor
    {
        private readonly GraphHelper graphHelper;
        private readonly IConfiguration config;
        private readonly HttpClient client = new HttpClient();
        private readonly SemaphoreSlim throttler;

        public ConferenceProcessor(GraphHelper helper, IConfiguration config)
        {
            this.graphHelper = helper;
            this.config = config;
            int maxThreads = Environment.ProcessorCount;
            this.throttler = new SemaphoreSlim(maxThreads);
        }

        public async Task ProcessConferenceIdsAsync()
        {
            var conferenceIds = await File.ReadAllLinesAsync(config["Paths:InputCsvPath"]);
            Directory.CreateDirectory(config["Paths:OutputFolder"]);
            var errorBag = new ConcurrentBag<string>();

            var tasks = conferenceIds.Select(async id =>
            {
                await throttler.WaitAsync();
                try
                {
                    await ProcessConferenceIdAsync(id, errorBag);
                }
                catch (Exception ex)
                {
                    Log.Error($"Error processing {id}: {ex.Message}");
                    errorBag.Add($"{id},{ex.Message}");
                }
                finally
                {
                    throttler.Release();
                }
            });

            await Task.WhenAll(tasks);

            await File.WriteAllLinesAsync(config["Paths:ErrorCsvPath"], errorBag);
        }

        private async Task ProcessConferenceIdAsync(string id, ConcurrentBag<string> errorBag)
        {
            string token = await graphHelper.GetAccessTokenAsync();
            var data = new JsonDocumentOptions();
            var result = new JsonDocumentOptions();

            string baseUrl = $"https://graph.microsoft.com/beta/communications/callRecords/{id}";
            string[] expandEntities = { "sessions", "sessions/segments", "participants_v2" };

            var fullData = new JsonDocumentOptions();

            await ExecuteWithRetryAsync(async () =>
            {
                foreach (var expand in expandEntities)
                {
                    string url = baseUrl + $"?$expand={expand}";
                    while (!string.IsNullOrEmpty(url))
                    {
                        using var request = new HttpRequestMessage(HttpMethod.Get, url);
                        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
                        var response = await client.SendAsync(request);
                        string content = await response.Content.ReadAsStringAsync();

                        if (response.IsSuccessStatusCode)
                        {
                            await File.WriteAllTextAsync($"{config["Paths:OutputFolder"]}/{id}.json", content);
                            url = null;
                        }
                        else if ((int)response.StatusCode == 429)
                        {
                            Log.Warning("Throttled. Waiting 30 sec...");
                            await Task.Delay(30000);
                        }
                        else if (content.Contains("Lifetime token"))
                        {
                            token = await graphHelper.GetAccessTokenAsync(true);
                        }
                        else
                        {
                            throw new Exception($"API Error: {response.StatusCode} {content}");
                        }
                    }
                }
            });
        }

        private async Task ExecuteWithRetryAsync(Func<Task> operation, int maxRetries = 3, int delayMs = 5000)
        {
            int retryCount = 0;
            while (true)
            {
                try
                {
                    await operation();
                    break;
                }
                catch (Exception ex)
                {
                    retryCount++;
                    if (retryCount > maxRetries)
                    {
                        Log.Error($"Retry limit exceeded: {ex.Message}");
                        throw;
                    }
                    Log.Warning($"Retry {retryCount}/{maxRetries}: {ex.Message}");
                    await Task.Delay(delayMs);
                }
            }
        }
    }
}
