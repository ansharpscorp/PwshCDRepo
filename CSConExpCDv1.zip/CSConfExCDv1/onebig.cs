// appsettings.json
{
  "Graph": {
    "TenantId": "<Your-Tenant-Id>",
    "ClientId": "<Your-Client-Id>",
    "ClientSecret": "<Your-Client-Secret>"
  },
  "Logging": {
    "LogFilePath": "log.txt",
    "ErrorCsvPath": "FailedCalls.csv"
  },
  "Output": {
    "JsonDirectory": "OutputJson"
  }
}

// Program.cs
using Microsoft.Extensions.Configuration;
using Serilog;
using System;
using System.IO;
using System.Threading.Tasks;

namespace TeamsGraphApiExpander
{
    class Program
    {
        static async Task Main(string[] args)
        {
            IConfiguration config = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json")
                .Build();

            Log.Logger = new LoggerConfiguration()
                .WriteTo.Console()
                .WriteTo.File(config["Logging:LogFilePath"], rollingInterval: RollingInterval.Day)
                .CreateLogger();

            string csvPath = args.Length > 0 ? args[0] : "ConferenceIds.csv";

            var processor = new ConferenceProcessor(config);
            await processor.ProcessConferenceIdsAsync(csvPath);

            Log.CloseAndFlush();
        }
    }
}

// GraphHelper.cs
using Microsoft.Extensions.Configuration;
using Microsoft.Identity.Client;
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace TeamsGraphApiExpander
{
    public class GraphHelper
    {
        private readonly IConfidentialClientApplication app;
        private readonly string[] scopes = new[] { "https://graph.microsoft.com/.default" };

        public GraphHelper(IConfiguration config)
        {
            app = ConfidentialClientApplicationBuilder.Create(config["Graph:ClientId"])
                .WithClientSecret(config["Graph:ClientSecret"])
                .WithAuthority(new Uri($"https://login.microsoftonline.com/{config["Graph:TenantId"]}"))
                .Build();
        }

        public async Task<string> GetAccessTokenAsync(bool forceRefresh = false)
        {
            var result = await app.AcquireTokenForClient(scopes)
                .WithForceRefresh(forceRefresh)
                .ExecuteAsync();
            return result.AccessToken;
        }
    }
}

// ConferenceProcessor.cs
using Microsoft.Extensions.Configuration;
using Serilog;
using System;
using System.Collections.Concurrent;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace TeamsGraphApiExpander
{
    public class ConferenceProcessor
    {
        private readonly GraphHelper graphHelper;
        private readonly string outputDir;
        private readonly string errorCsvPath;
        private readonly SemaphoreSlim throttler = new SemaphoreSlim(4);
        private readonly HttpClient client = new HttpClient();

        public ConferenceProcessor(IConfiguration config)
        {
            graphHelper = new GraphHelper(config);
            outputDir = config["Output:JsonDirectory"];
            errorCsvPath = config["Logging:ErrorCsvPath"];

            if (!Directory.Exists(outputDir))
                Directory.CreateDirectory(outputDir);
        }

        public async Task ProcessConferenceIdsAsync(string csvPath)
        {
            var ids = await File.ReadAllLinesAsync(csvPath);
            var tasks = new ConcurrentBag<Task>();

            foreach (var id in ids)
            {
                tasks.Add(ProcessConferenceIdAsync(id.Trim()));
            }

            await Task.WhenAll(tasks);
        }

        private async Task ProcessConferenceIdAsync(string id)
        {
            await throttler.WaitAsync();
            try
            {
                Log.Information($"Processing ConferenceId: {id}");
                string token = await graphHelper.GetAccessTokenAsync();
                string baseUrl = $"https://graph.microsoft.com/beta/communications/callRecords/{id}?$expand=sessions($expand=segments),participants_v2";

                await ExecuteWithRetryAsync(async () =>
                {
                    string jsonResult = await GetGraphResultAsync(baseUrl, token);
                    string outputPath = Path.Combine(outputDir, $"{id}.json");
                    await File.WriteAllTextAsync(outputPath, jsonResult);
                }, id);
            }
            catch (Exception ex)
            {
                Log.Error($"Failed to process {id}: {ex.Message}");
                await File.AppendAllTextAsync(errorCsvPath, $"{id},{ex.Message}\n");
            }
            finally
            {
                throttler.Release();
            }
        }

        private async Task<string> GetGraphResultAsync(string url, string token)
        {
            string fullContent = string.Empty;

            while (!string.IsNullOrEmpty(url))
            {
                using var request = new HttpRequestMessage(HttpMethod.Get, url);
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

                var response = await client.SendAsync(request);
                var content = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode)
                {
                    fullContent = content;
                    var doc = JsonDocument.Parse(content);
                    url = doc.RootElement.TryGetProperty("@odata.nextLink", out var nextLink) ? nextLink.GetString() : null;
                }
                else
                {
                    if ((int)response.StatusCode == 429)
                    {
                        await Task.Delay(30000);
                        continue;
                    }
                    else if (content.Contains("Lifetime token"))
                    {
                        token = await graphHelper.GetAccessTokenAsync(true);
                        continue;
                    }
                    else
                    {
                        throw new Exception($"Graph API error: {content}");
                    }
                }
            }

            return fullContent;
        }

        private async Task ExecuteWithRetryAsync(Func<Task> operation, string id, int maxRetries = 3, int delayMs = 5000)
        {
            int retryCount = 0;
            while (true)
            {
                try
                {
                    await operation();
                    break;
                }
                catch (Exception ex)
                {
                    retryCount++;
                    if (retryCount > maxRetries)
                    {
                        await File.AppendAllTextAsync(errorCsvPath, $"{id},{ex.Message}\n");
                        throw;
                    }
                    await Task.Delay(delayMs);
                }
            }
        }
    }
}
