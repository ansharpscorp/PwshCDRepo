// Program.cs
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Serilog;

namespace TeamsGraphApiCaller
{
    class Program
    {
        static async Task Main(string[] args)
        {
            IConfiguration config = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false)
                .Build();

            Log.Logger = new LoggerConfiguration()
                .WriteTo.Console()
                .WriteTo.File(config["Logging:LogFilePath"], rollingInterval: RollingInterval.Day)
                .CreateLogger();

            if (args.Length != 3)
            {
                Log.Error("Usage: dotnet run <Date:yyyy-MM-dd> <StartHour:int> <EndHour:int>");
                return;
            }

            DateTime date = DateTime.ParseExact(args[0], "yyyy-MM-dd", CultureInfo.InvariantCulture);
            int startHour = int.Parse(args[1]);
            int endHour = int.Parse(args[2]);

            string outputFile = $"ConferenceIds_{date:yyyyMMdd}.csv";
            var graphHelper = new GraphHelper(config);
            var processor = new IntervalProcessor(graphHelper, outputFile);

            List<Task> tasks = new List<Task>();

            for (int hour = startHour; hour <= endHour; hour++)
            {
                for (int minute = 0; minute < 60; minute += 15)
                {
                    DateTime startTime = new DateTime(date.Year, date.Month, date.Day, hour, minute, 0, DateTimeKind.Utc);
                    DateTime endTime = startTime.AddMinutes(15);
                    tasks.Add(processor.ProcessIntervalAsync(startTime, endTime));
                }
            }

            await Task.WhenAll(tasks);
            await processor.WriteResultsAsync();

            Log.CloseAndFlush();
        }
    }
}