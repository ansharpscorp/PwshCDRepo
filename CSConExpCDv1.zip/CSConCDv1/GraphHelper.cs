// GraphHelper.cs
using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Identity.Client;

namespace TeamsGraphApiCaller
{
    public class GraphHelper
    {
        private string tenantId, clientId, clientSecret;
        private IConfidentialClientApplication app;
        private string[] scopes = new[] { "https://graph.microsoft.com/.default" };

        public GraphHelper(IConfiguration config)
        {
            tenantId = config["Graph:TenantId"];
            clientId = config["Graph:ClientId"];
            clientSecret = config["Graph:ClientSecret"];

            app = ConfidentialClientApplicationBuilder.Create(clientId)
                .WithClientSecret(clientSecret)
                .WithAuthority(new Uri($"https://login.microsoftonline.com/{tenantId}"))
                .Build();
        }

        public async Task<string> GetAccessTokenAsync(bool forceRefresh = false)
        {
            var result = await app.AcquireTokenForClient(scopes)
                .WithForceRefresh(forceRefresh)
                .ExecuteAsync();
            return result.AccessToken;
        }
    }
}