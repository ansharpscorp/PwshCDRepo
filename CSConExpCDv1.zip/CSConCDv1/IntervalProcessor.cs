// IntervalProcessor.cs
using System;
using System.Collections.Concurrent;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Serilog;

namespace TeamsGraphApiCaller
{
    public class IntervalProcessor
    {
        private readonly GraphHelper graphHelper;
        private readonly string outputFile;
        private readonly ConcurrentBag<string> conferenceIds = new ConcurrentBag<string>();
        private readonly SemaphoreSlim throttler = new SemaphoreSlim(4);
        private readonly HttpClient client = new HttpClient();

        public IntervalProcessor(GraphHelper helper, string outputFile)
        {
            this.graphHelper = helper;
            this.outputFile = outputFile;
        }

        public async Task ProcessIntervalAsync(DateTime startTime, DateTime endTime)
        {
            await throttler.WaitAsync();
            try
            {
                Log.Information($"Processing interval: {startTime:o} to {endTime:o}");
                string token = await graphHelper.GetAccessTokenAsync();
                string url = $"https://graph.microsoft.com/beta/communications/callRecords?fromDateTime={startTime:o}&toDateTime={endTime:o}";

                await ExecuteWithRetryAsync(async () =>
                {
                    while (!string.IsNullOrEmpty(url))
                    {
                        using HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, url);
                        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

                        HttpResponseMessage response = await client.SendAsync(request);
                        string content = await response.Content.ReadAsStringAsync();

                        if (response.IsSuccessStatusCode)
                        {
                            using JsonDocument doc = JsonDocument.Parse(content);
                            if (doc.RootElement.TryGetProperty("value", out JsonElement value))
                            {
                                foreach (var item in value.EnumerateArray())
                                {
                                    if (item.TryGetProperty("id", out JsonElement id))
                                    {
                                        string idVal = id.GetString();
                                        conferenceIds.Add(idVal);
                                        Log.Information($"Fetched ConferenceId: {idVal}");
                                    }
                                }
                            }
                            url = doc.RootElement.TryGetProperty("@odata.nextLink", out JsonElement nextLink) ? nextLink.GetString() : null;
                        }
                        else if ((int)response.StatusCode == 429)
                        {
                            Log.Warning("Throttled. Retrying after 30 sec...");
                            await Task.Delay(30000);
                        }
                        else if (content.Contains("Lifetime token"))
                        {
                            token = await graphHelper.GetAccessTokenAsync(true);
                        }
                        else
                        {
                            Log.Error($"Error: {response.StatusCode}\n{content}");
                            break;
                        }
                    }
                });
            }
            catch (Exception ex)
            {
                Log.Error($"Exception: {ex.Message}");
            }
            finally
            {
                throttler.Release();
            }
        }

        private async Task ExecuteWithRetryAsync(Func<Task> operation, int maxRetries = 3, int delayMs = 5000)
        {
            int retryCount = 0;
            while (true)
            {
                try
                {
                    await operation();
                    break;
                }
                catch (Exception ex)
                {
                    retryCount++;
                    if (retryCount > maxRetries)
                    {
                        Log.Error($"Retry limit exceeded. Exception: {ex.Message}");
                        throw;
                    }
                    Log.Warning($"Retry {retryCount}/{maxRetries} after error: {ex.Message}");
                    await Task.Delay(delayMs);
                }
            }
        }

        public async Task WriteResultsAsync()
        {
            using (var writer = new StreamWriter(outputFile, append: true))
            {
                foreach (var id in conferenceIds)
                {
                    await writer.WriteLineAsync(id);
                }
            }
            Log.Information($"Appended {conferenceIds.Count} ConferenceIds to {outputFile}");
        }
    }
}
