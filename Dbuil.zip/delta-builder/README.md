# Delta Builder (ADLS Gen2 → Delta Lake)
Creates a Delta Lake dataset from Parquet in folders YYYY/MM/dd and supports incremental appends.

Install:
  pip install -r requirements.txt

Run:
  python -m src.main
