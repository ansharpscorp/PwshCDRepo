import json, os
from pyspark.sql import functions as F

from .spark_builder import build_spark
from .delta_utils import existing_dates, normalize_with_date, distinct_source_dates

def load_settings(root):
    with open(os.path.join(root, "settings.json"), "r", encoding="utf-8") as f:
        return json.load(f)

def compute_partitions(df, target_file_mb: int):
    days = df.select(F.col("Date")).distinct().count()
    return max(days * 8, 1)

def write_delta(df, out_path: str, mode: str, target_file_mb: int, register_table: str):
    parts = compute_partitions(df, target_file_mb)
    df = df.repartition(parts, "Date")
    (df.write.format("delta")
        .mode("append" if mode == "append" else "overwrite")
        .partitionBy("Date")
        .option("parquet.enable.dictionary", "true")
        .option("parquet.compression", "snappy")
        .save(out_path))
    if register_table:
        spark = df.spark_session
        spark.sql(f"CREATE TABLE IF NOT EXISTS {register_table} USING DELTA LOCATION '{out_path}'")
        spark.catalog.refreshTable(register_table)

def main():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    cfg = load_settings(root)

    acct = cfg["adls"]["account_name"]
    tenant = cfg["adls"]["tenant_id"]
    client = cfg["adls"]["client_id"]
    secret = cfg["adls"]["client_secret"]

    input_base = cfg["paths"]["input_base"].rstrip("/")
    out_delta  = cfg["paths"]["output_delta"].rstrip("/")

    mode = cfg["write"].get("mode", "append").lower()
    target_file_mb = int(cfg["write"].get("target_file_mb", 192))
    register_table = cfg["write"].get("register_table", "")

    spark = build_spark("DeltaBuilder", acct, tenant, client, secret)

    src_df = spark.read.parquet(input_base)
    src_df = normalize_with_date(src_df)

    if mode == "append":
        have = existing_dates(spark, out_delta, "Date")
        src_dates = distinct_source_dates(src_df)
        new_dates = sorted(src_dates - have)
        if not new_dates:
            print("No new dates to append. ✅")
            return
        df = src_df.where(F.col("Date").cast("string").isin(new_dates))
        print(f"Appending {len(new_dates)} date(s): {new_dates[:10]}{' ...' if len(new_dates) > 10 else ''}")
        write_delta(df, out_delta, "append", target_file_mb, register_table)
    else:
        print("Overwriting entire Delta dataset from source Parquet ...")
        write_delta(src_df, out_delta, "overwrite", target_file_mb, register_table)

    print(f"✅ Done. Delta at: {out_delta}")

if __name__ == "__main__":
    main()
