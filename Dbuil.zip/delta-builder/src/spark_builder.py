from pyspark.sql import SparkSession
from delta import configure_spark_with_delta_pip

def build_spark(app_name, account_name, tenant_id, client_id, client_secret):
    builder = (
        SparkSession.builder.appName(app_name)
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
        .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
        .config(f"spark.hadoop.fs.azure.account.auth.type.{account_name}.dfs.core.windows.net", "OAuth")
        .config(f"spark.hadoop.fs.azure.account.oauth.provider.type.{account_name}.dfs.core.windows.net",
                "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
        .config(f"spark.hadoop.fs.azure.account.oauth2.client.id.{account_name}.dfs.core.windows.net", client_id)
        .config(f"spark.hadoop.fs.azure.account.oauth2.client.secret.{account_name}.dfs.core.windows.net", client_secret)
        .config(f"spark.hadoop.fs.azure.account.oauth2.client.endpoint.{account_name}.dfs.core.windows.net",
                f"https://login.microsoftonline.com/{tenant_id}/oauth2/token")
        .config("spark.sql.files.ignoreMissingFiles", "true")
        .config("spark.sql.shuffle.partitions", "200")
    )
    spark = configure_spark_with_delta_pip(builder).getOrCreate()
    spark.sparkContext.setLogLevel("WARN")
    return spark
