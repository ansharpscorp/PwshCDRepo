from typing import Set
from pyspark.sql import functions as F
from delta.tables import DeltaTable

def is_delta(spark, path: str) -> bool:
    try:
        return DeltaTable.isDeltaTable(spark, path)
    except Exception:
        return False

def existing_dates(spark, delta_path: str, date_col: str = "Date") -> Set[str]:
    if not is_delta(spark, delta_path):
        return set()
    df = spark.read.format("delta").load(delta_path)
    if date_col not in df.columns:
        return set()
    return set(r[0] for r in df.select(F.col(date_col).cast("string")).distinct().collect())

def normalize_with_date(df):
    cols = df.columns
    y = "YYYY" if "YYYY" in cols else ("year" if "year" in cols else None)
    m = "MM" if "MM" in cols else ("month" if "month" in cols else None)
    d = "dd" if "dd" in cols else ("day" if "day" in cols else None)

    if y and m and d:
        return df.withColumn(
            "Date",
            F.to_date(F.concat_ws("-", F.col(y).cast("string"),
                                       F.lpad(F.col(m).cast("string"), 2, "0"),
                                       F.lpad(F.col(d).cast("string"), 2, "0")))
        )
    else:
        parts = F.split(F.input_file_name(), "/")
        df = (df
              .withColumn("YYYY", F.element_at(parts, -4))
              .withColumn("MM",   F.element_at(parts, -3))
              .withColumn("dd",   F.element_at(parts, -2)))
        return df.withColumn(
            "Date",
            F.to_date(F.concat_ws("-", F.col("YYYY"),
                                       F.lpad(F.col("MM"), 2, "0"),
                                       F.lpad(F.col("dd"), 2, "0")))
        )

def distinct_source_dates(df) -> set:
    return set(r[0] for r in df.select(F.col("Date").cast("string")).distinct().collect())
