# GitLab Issue Auto-Assign (Modular Version)

## Overview

Automated assignment of new GitLab issues to specified users via CI/CD scheduled pipeline. Modular codebase for maintainability and testing.

## Structure

- `scripts/gitlab_api.py` — GitLab API access functions
- `scripts/issue_utils.py` — Parsing, filtering, and field utilities
- `scripts/assign_issues.py` — Main orchestration script
- `requirements.txt` — Python dependencies
- `.gitlab-ci.yml` — Pipeline definition
## Setup

1. Fill in CI/CD variables in `.gitlab-ci.yml`.
2. Schedule pipeline as needed.
3. Extend functionality by editing or adding scripts in `scripts/`.

