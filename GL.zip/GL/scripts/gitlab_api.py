import os
import requests

GITLAB_API_URL = os.environ['GITLAB_API_URL']
PRIVATE_TOKEN = os.environ['PRIVATE_TOKEN']
PROJECT_ID = os.environ['PROJECT_ID']

def get_new_issues(since_time):
    url = f"{GITLAB_API_URL}/projects/{PROJECT_ID}/issues"
    params = {"created_after": since_time}
    resp = requests.get(url, headers={"PRIVATE-TOKEN": PRIVATE_TOKEN}, params=params)
    resp.raise_for_status()
    return resp.json()

def assign_issue(issue_iid, assignee_ids):
    url = f"{GITLAB_API_URL}/projects/{PROJECT_ID}/issues/{issue_iid}"
    resp = requests.put(
        url,
        headers={"PRIVATE-TOKEN": PRIVATE_TOKEN},
        json={"assignee_ids": assignee_ids}
    )
    return resp.status_code == 200
