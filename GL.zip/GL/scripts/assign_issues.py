import os
import datetime
from gitlab_api import get_new_issues, assign_issue
from issue_utils import parse_issue_fields

ASSIGNEE_IDS = [int(i) for i in os.environ['ASSIGNEE_IDS'].split(',')]
MINUTES_BACK = int(os.environ.get('MINUTES_BACK', 15))

def main():
    since_time = (datetime.datetime.utcnow() - datetime.timedelta(minutes=MINUTES_BACK)).isoformat() + "Z"
    issues = get_new_issues(since_time)
    for issue in issues:
        # Optionally, parse fields or filter issues here
        assign_issue(issue['iid'], ASSIGNEE_IDS)
        print(f"Issue #{issue['iid']} assigned to {ASSIGNEE_IDS}")

if __name__ == "__main__":
    main()
