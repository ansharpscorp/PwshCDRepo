import re

FIELDS = [
    "AppName", "ENV", "APPID", "DL",
    "OwnerId", "GroupName", "Check box option", "IP", "Websitename"
]

def parse_issue_fields(desc):
    fields = {}
    for field in FIELDS:
        m = re.search(rf'{field}\s*:\s*(.*)', desc)
        fields[field] = m.group(1).strip() if m else ''
    return fields
