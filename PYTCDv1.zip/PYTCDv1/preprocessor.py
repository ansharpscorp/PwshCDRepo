import os
from datetime import datetime, timedelta
from fetcher import process_interval
from config import OUTPUT_ROOT
from concurrent.futures import ThreadPoolExecutor
import logging

logging.basicConfig(filename='logs/downloader.log', level=logging.INFO)

def process_day(start_date, end_date, start_hour, end_hour):
    start_dt = datetime.strptime(start_date, "%Y-%m-%d")
    end_dt = datetime.strptime(end_date, "%Y-%m-%d")

    while start_dt <= end_dt:
        date_str = start_dt.strftime("%Y-%m-%d")
        os.makedirs(os.path.join(OUTPUT_ROOT, start_dt.strftime("%Y/%m/%d")), exist_ok=True)

        with ThreadPoolExecutor(max_workers=4) as executor:
            for hour in range(start_hour, end_hour):
                for minute in range(0, 60, 15):
                    start_time = start_dt.replace(hour=hour, minute=minute, second=0)
                    end_time = start_time + timedelta(minutes=15)
                    executor.submit(process_interval, start_time, end_time)

        start_dt += timedelta(days=1)
