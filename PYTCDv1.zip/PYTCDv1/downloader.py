import sys
from processor import process_day

if __name__ == "__main__":
    if len(sys.argv) < 5:
        print("Usage: python downloader.py <start_date> <end_date> <start_hour> <end_hour>")
        sys.exit(1)

    start_date, end_date, start_hour, end_hour = sys.argv[1:5]
    process_day(start_date, end_date, int(start_hour), int(end_hour))
