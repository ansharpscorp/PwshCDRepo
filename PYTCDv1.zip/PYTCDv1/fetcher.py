import os
import requests
import json
from datetime import datetime
from config import GRAPH_URL, OUTPUT_ROOT, get_token
import logging
from tenacity import retry, wait_exponential, stop_after_attempt

logging.basicConfig(filename='logs/downloader.log', level=logging.INFO)

@retry(wait=wait_exponential(multiplier=1, min=2, max=30), stop=stop_after_attempt(5))
def fetch_call_records(start_time, end_time, token):
    headers = {"Authorization": f"Bearer {token}"}
    start = start_time.strftime("%Y-%m-%dT%H:%M:%SZ")
    end = end_time.strftime("%Y-%m-%dT%H:%M:%SZ")
    url = f"{GRAPH_URL}?$filter=startDateTime ge {start} and startDateTime lt {end}"

    records = []
    while url:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        data = response.json()
        records.extend(data.get('value', []))
        url = data.get('@odata.nextLink')

    return records

def expand_and_save(record, date_folder, token):
    conf_id = record['id']
    output_path = os.path.join(date_folder, f"{conf_id}.json")

    if os.path.exists(output_path):
        logging.info(f"Skipping existing {output_path}")
        return

    headers = {"Authorization": f"Bearer {token}"}

    sessions = fetch_expand(f"{GRAPH_URL}/{conf_id}/sessions?$expand=segments", headers)
    participants = fetch_expand(f"{GRAPH_URL}/{conf_id}/participants_v2", headers)

    result = {
        "endDateTime": record.get("endDateTime"),
        "id": conf_id,
        "joinWebUrl": record.get("joinWebUrl"),
        "lastModifiedDateTime": record.get("lastModifiedDateTime"),
        "modalities": record.get("modalities"),
        "organizer": record.get("organizer"),
        "participants": record.get("participants"),
        "startDateTime": record.get("startDateTime"),
        "type": record.get("type"),
        "version": record.get("version"),
        "participants_v2": participants,
        "sessions": sessions
    }

    with open(output_path, 'w') as f:
        json.dump(result, f, indent=2)

@retry(wait=wait_exponential(multiplier=1, min=2, max=30), stop=stop_after_attempt(5))
def fetch_expand(url, headers):
    items = []
    while url:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        data = response.json()
        items.extend(data.get('value', []))
        url = data.get('@odata.nextLink')
    return items

def process_interval(start_time, end_time):
    try:
        token = get_token()
        records = fetch_call_records(start_time, end_time, token)
        date_folder = os.path.join(OUTPUT_ROOT, start_time.strftime("%Y/%m/%d"))
        os.makedirs(date_folder, exist_ok=True)

        for rec in records:
            expand_and_save(rec, date_folder, token)
    except Exception as e:
        logging.error(f"Error processing interval {start_time} - {end_time}: {e}")
