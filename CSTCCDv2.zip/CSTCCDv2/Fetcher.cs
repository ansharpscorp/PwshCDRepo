// File: Fetcher.cs
using Newtonsoft.Json.Linq;
using Polly;
using Polly.Retry;
using Serilog;
using System;
using System.Collections.Concurrent;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace TeamsCdrDownloader
{
    public static class Fetcher
    {
        private static readonly AsyncRetryPolicy<HttpResponseMessage> retryPolicy = Policy
            .HandleResult<HttpResponseMessage>(r => !r.IsSuccessStatusCode)
            .WaitAndRetryAsync(5, attempt => TimeSpan.FromSeconds(2 * attempt));

        public static async Task ProcessIntervalAsync(string token, DateTime date, DateTime start, DateTime end)
        {
            var records = await FetchCallRecordsAsync(token, start, end);
            var folderPath = Path.Combine(Config.OutputRoot, date.ToString("yyyy"), date.ToString("MM"), date.ToString("dd"));
            Directory.CreateDirectory(folderPath);

            var tasks = records.Select(rec => ProcessRecordAsync(token, rec, folderPath)).ToList();
            await Task.WhenAll(tasks);
        }

        public static async Task<JArray> FetchCallRecordsAsync(string token, DateTime start, DateTime end)
        {
            string url = $"{Config.GraphUrl}?$filter=startDateTime ge {start:yyyy-MM-ddTHH:mm:ssZ} and startDateTime lt {end:yyyy-MM-ddTHH:mm:ssZ}";
            using var client = new HttpClient();
            client.DefaultRequestHeaders.Add("Authorization", $"Bearer {token}");

            var allRecords = new JArray();
            while (!string.IsNullOrEmpty(url))
            {
                var response = await retryPolicy.ExecuteAsync(() => client.GetAsync(url));
                var json = JObject.Parse(await response.Content.ReadAsStringAsync());
                var values = (JArray?)json["value"] ?? new JArray();
                foreach (var item in values) allRecords.Add(item);
                url = json["@odata.nextLink"]?.ToString();
            }
            return allRecords;
        }

        public static async Task ProcessRecordAsync(string token, JToken rec, string folderPath)
        {
            string? id = rec["id"]?.ToString();
            if (string.IsNullOrEmpty(id)) return;

            string filePath = Path.Combine(folderPath, $"{id}.json");
            if (File.Exists(filePath)) return;

            try
            {
                var sessions = await ExpandDataAsync(token, id, "sessions?$expand=segments");
                var participantsV2 = await ExpandDataAsync(token, id, "participants_v2");

                var result = new JObject
                {
                    ["endDateTime"] = rec["endDateTime"],
                    ["id"] = rec["id"],
                    ["joinWebUrl"] = rec["joinWebUrl"],
                    ["lastModifiedDateTime"] = rec["lastModifiedDateTime"],
                    ["modalities"] = rec["modalities"],
                    ["organizer"] = rec["organizer"],
                    ["participants"] = rec["participants"],
                    ["startDateTime"] = rec["startDateTime"],
                    ["type"] = rec["type"],
                    ["version"] = rec["version"],
                    ["participants_v2"] = participantsV2,
                    ["sessions"] = sessions
                };

                await File.WriteAllTextAsync(filePath, result.ToString());
            }
            catch (Exception ex)
            {
                Log.Error($"Failed to process {id}: {ex.Message}");
                await File.AppendAllTextAsync(Config.FailedCsv, $"{id},{ex.Message}\n");
            }
        }

        private static async Task<JArray> ExpandDataAsync(string token, string id, string endpoint)
        {
            string url = $"{Config.GraphUrl}/{id}/{endpoint}";
            using var client = new HttpClient();
            client.DefaultRequestHeaders.Add("Authorization", $"Bearer {token}");

            var allData = new JArray();
            while (!string.IsNullOrEmpty(url))
            {
                var response = await retryPolicy.ExecuteAsync(() => client.GetAsync(url));
                var json = JObject.Parse(await response.Content.ReadAsStringAsync());
                var values = (JArray?)json["value"] ?? new JArray();
                foreach (var item in values) allData.Add(item);
                url = json["@odata.nextLink"]?.ToString();
            }
            return allData;
        }
    }
}