// File: Program.cs
using System;
using System.Threading.Tasks;

namespace TeamsCdrDownloader
{
    class Program
    {
        static async Task Main(string[] args)
        {
            if (args.Length < 3)
            {
                Console.WriteLine("Usage: TeamsCdrDownloader <date> <startHour> <endHour>");
                return;
            }

            string date = args[0];
            int startHour = int.Parse(args[1]);
            int endHour = int.Parse(args[2]);

            await Processor.ProcessDayAsync(date, startHour, endHour);
        }
    }
}