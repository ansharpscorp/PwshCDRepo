// File: Processor.cs
using Polly;
using Polly.Retry;
using Serilog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace TeamsCdrDownloader
{
    public static class Processor
    {
        public static async Task ProcessDayAsync(string dateStr, int startHour, int endHour)
        {
            Directory.CreateDirectory(Config.OutputRoot);
            Log.Logger = new LoggerConfiguration().WriteTo.File("log.txt").CreateLogger();

            var token = await TokenHelper.GetAccessTokenAsync();
            var date = DateTime.Parse(dateStr);

            int startInterval = (startHour * 60) / 15;
            int endInterval = (endHour * 60) / 15;

            var throttler = new SemaphoreSlim(Config.MaxDegreeOfParallelism);
            var tasks = new List<Task>();

            for (int i = startInterval; i < endInterval; i++)
            {
                var start = date.AddMinutes(15 * i);
                var end = start.AddMinutes(15);

                await throttler.WaitAsync();
                tasks.Add(Task.Run(async () =>
                {
                    try { await Fetcher.ProcessIntervalAsync(token, date, start, end); }
                    finally { throttler.Release(); }
                }));
            }

            await Task.WhenAll(tasks);
        }
    }
}