from datetime import datetime

class GraphTokenManager:
    def __init__(self, tenant_id, client_id, client_secret, logger):
        self.tenant_id = tenant_id
        self.client_id = client_id
        self.client_secret = client_secret
        self.token = None
        self.token_expires = 0
        self.logger = logger

    async def get_token(self, session):
        now = datetime.utcnow().timestamp()
        if not self.token or self.token_expires - now < 300:
            url = f"https://login.microsoftonline.com/{self.tenant_id}/oauth2/v2.0/token"
            data = {
                'client_id': self.client_id,
                'client_secret': self.client_secret,
                'scope': 'https://graph.microsoft.com/.default',
                'grant_type': 'client_credentials'
            }
            async with session.post(url, data=data) as resp:
                if resp.status != 200:
                    msg = f"Token fetch failed: {resp.status} {await resp.text()}"
                    self.logger.error(msg)
                    resp.raise_for_status()
                tok = await resp.json()
                self.token = tok['access_token']
                self.token_expires = now + int(tok['expires_in'])
                self.logger.info("Fetched new access token")
        return self.token
