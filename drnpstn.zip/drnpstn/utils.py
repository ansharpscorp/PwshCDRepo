import yaml
import json
import logging
import os
from datetime import datetime, timedelta

class CustomFormatter(logging.Formatter):
    def format(self, record):
        dt = datetime.fromtimestamp(record.created).strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
        return f"{dt} | {record.levelname:<8} | {record.funcName:<30} | {record.getMessage()}"

def setup_logger(logfile='downloader.log'):
    logger = logging.getLogger(logfile)  # Allow per-file loggers!
    logger.setLevel(logging.INFO)
    # Remove handlers if already set (important for per-day loggers)
    if logger.hasHandlers():
        logger.handlers.clear()
    fh = logging.FileHandler(logfile)
    formatter = CustomFormatter()
    fh.setFormatter(formatter)
    logger.addHandler(fh)
    return logger

def load_config(path='config.json'):
    with open(path) as f:
        return json.load(f)

def load_columns(path='columns.yaml'):
    with open(path) as f:
        return yaml.safe_load(f)

def daterange(start_date, end_date):
    for n in range((end_date - start_date).days):
        yield start_date + timedelta(n)

def date_output_path(base_folder, dt, prefix):
    folder = os.path.join(
        base_folder,
        dt.strftime("%Y"),
        dt.strftime("%m"),
        dt.strftime("%d")
    )
    os.makedirs(folder, exist_ok=True)
    fname = f"{prefix}_{dt.strftime('%Y-%m-%d')}.csv"
    return os.path.join(folder, fname)

def day_logfile_path(base_folder, dt):
    logs_folder = os.path.join(base_folder, "_Logs")
    os.makedirs(logs_folder, exist_ok=True)
    logname = f"Logs_{dt.strftime('%Y-%m-%d')}.log"
    return os.path.join(logs_folder, logname)