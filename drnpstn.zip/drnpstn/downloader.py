import asyncio
import csv
from utils import date_output_path, day_logfile_path, setup_logger

async def fetch_graph_data(url, token_manager, session, logger, columns, max_retries=5):
    all_results = []
    tries = 0
    throttle_limit = 10
    backoff = 2

    while url:
        token = await token_manager.get_token(session)
        headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/json"
        }
        try:
            async with session.get(url, headers=headers, timeout=60) as resp:
                if resp.status == 429:
                    retry_after = int(resp.headers.get('Retry-After', 10))
                    tries += 1
                    logger.warning(f"429 Too Many Requests at {url} (Retry {tries}/{throttle_limit})")
                    await asyncio.sleep(retry_after * tries)
                    if tries > throttle_limit:
                        logger.error("Too many throttle retries. Aborting this job.")
                        return all_results
                    continue
                if resp.status >= 500:
                    logger.warning(f"Server error {resp.status} at {url} (Retry {tries+1}/{max_retries})")
                    tries += 1
                    await asyncio.sleep(backoff ** tries)
                    if tries > max_retries:
                        logger.error("Too many server errors, aborting.")
                        return all_results
                    continue
                if resp.status != 200:
                    logger.error(f"HTTP {resp.status}: {await resp.text()} at {url}")
                    return all_results
                data = await resp.json()
                if 'value' in data:
                    all_results.extend(data['value'])
                    url = data.get('@odata.nextLink', None)
                else:
                    all_results.append(data)
                    url = None
                tries = 0
        except asyncio.TimeoutError:
            logger.error(f"Timeout while fetching {url}")
            tries += 1
            if tries > max_retries:
                logger.critical("Giving up after repeated timeouts.")
                break
            await asyncio.sleep(backoff ** tries)
        except Exception as e:
            logger.critical(f"Uncaught exception at {url}: {e}", exc_info=True)
            break
    return all_results

def save_to_csv(records, filename, columns, logger):
    try:
        if not records:
            logger.info(f"No records for {filename}")
            return
        with open(filename, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=columns, extrasaction='ignore')
            writer.writeheader()
            for rec in records:
                writer.writerow(rec)
        logger.info(f"Saved: {filename} ({len(records)} records)")
    except Exception as e:
        logger.error(f"Error writing {filename}: {e}", exc_info=True)

async def fetch_for_day(dt, token_manager, session, columns, output_folder, parent_logger):
    from datetime import timedelta
    # Each day gets its own log file in _Logs
    log_path = day_logfile_path(output_folder, dt)
    logger = setup_logger(log_path)

    day_start = dt
    day_end = dt + timedelta(days=1)
    tasks = []
    meta = [
        ("PSTN", f"https://graph.microsoft.com/v1.0/communications/callRecords/getPstnCalls"
                 f"(fromDateTime={day_start.isoformat()},toDateTime={day_end.isoformat()})?$top=1000"),
        ("DR", f"https://graph.microsoft.com/v1.0/communications/callRecords/getDirectRoutingCalls"
               f"(fromDateTime={day_start.isoformat()},toDateTime={day_end.isoformat()})?$top=1000")
    ]

    for call_type, url in meta:
        fname = date_output_path(output_folder, dt, call_type)
        colset = columns[call_type]
        tasks.append(
            fetch_and_save(url, token_manager, session, fname, colset, logger, call_type)
        )
    await asyncio.gather(*tasks)

async def fetch_and_save(url, token_manager, session, fname, colset, logger, call_type):
    logger.info(f"Starting download for {call_type}: {fname}")
    records = await fetch_graph_data(url, token_manager, session, logger, colset)
    save_to_csv(records, fname, colset, logger)
