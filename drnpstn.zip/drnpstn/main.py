import argparse
import os
import asyncio
from datetime import datetime

from utils import setup_logger, load_config, load_columns, daterange
from graph_auth import GraphTokenManager
from downloader import fetch_for_day

def resolve_config_and_args(args, config):
    # CLI args override config, else config is used
    logfile = args.logfile or config.get("logfile", "downloader.log")
    output_folder = args.output or config.get("output_folder", ".")
    return logfile, output_folder

async def main_async(config, columns, start_date, end_date, output_folder, parent_logger):
    import aiohttp
    token_manager = GraphTokenManager(
        config['tenant_id'],
        config['client_id'],
        config['client_secret'],
        parent_logger
    )
    async with aiohttp.ClientSession() as session:
        all_tasks = []
        for dt in daterange(start_date, end_date):
            all_tasks.append(fetch_for_day(dt, token_manager, session, columns, output_folder, parent_logger))
        try:
            await asyncio.gather(*all_tasks)
        except Exception as e:
            parent_logger.critical(f"Fatal error in async downloads: {e}", exc_info=True)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Download Teams PSTN and DR call logs per day (async/yaml/logging).")
    parser.add_argument("--config", default="config.json", help="Path to config.json")
    parser.add_argument("--columns", default="columns.yaml", help="Path to columns.yaml")
    parser.add_argument("--start-date", required=True, help="Start date (YYYY-MM-DD)")
    parser.add_argument("--end-date", required=True, help="End date (YYYY-MM-DD, exclusive)")
    parser.add_argument("--output", help="Output folder for CSV files")   # Optional, overrides config
    parser.add_argument("--logfile", help="Log file path")               # Optional, overrides config
    args = parser.parse_args()

    try:
        config = load_config(args.config)
    except Exception as e:
        print(f"Failed to load config.json: {e}")
        exit(1)
    try:
        columns = load_columns(args.columns)
    except Exception as e:
        print(f"Failed to load columns.yaml: {e}")
        exit(1)
    logfile, output_folder = resolve_config_and_args(args, config)

    parent_logger = setup_logger(logfile)
    try:
        start_date = datetime.strptime(args.start_date, "%Y-%m-%d")
        end_date = datetime.strptime(args.end_date, "%Y-%m-%d")
    except Exception as e:
        parent_logger.critical(f"Invalid date: {e}")
        exit(1)

    asyncio.run(main_async(config, columns, start_date, end_date, output_folder, parent_logger))
