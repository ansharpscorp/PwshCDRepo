from __future__ import annotations
import argparse
import os
import io
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Optional, Iterable, Tuple, Dict
from datetime import date, timedelta
import calendar
import logging

import yaml
import orjson
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from tqdm import tqdm

from azure.identity import DefaultAzureCredential
from azure_io import make_container_client, iter_json_blobs, download_text, upload_bytes
from flattener import build_rows
from settings_loader import load_settings, apply_auth_env, make_sp_credential

def setup_day_loggers(day: date):
    """Create 3 rotating loggers per day (processed, skipped, error)."""
    log_dir = os.path.join("logs")
    os.makedirs(log_dir, exist_ok=True)
    day_str = day.strftime("%Y%m%d")

    def _make_logger(name, suffix):
        logger = logging.getLogger(f"{name}_{day_str}")
        logger.setLevel(logging.INFO)
        fh = logging.FileHandler(os.path.join(log_dir, f"{suffix}_{day_str}.log"), encoding="utf-8")
        fmt = logging.Formatter("%(asctime)s  %(message)s")
        fh.setFormatter(fmt)
        logger.addHandler(fh)
        return logger

    return {
        "processed": _make_logger("processed", "processed"),
        "skipped": _make_logger("skipped", "skipped"),
        "error": _make_logger("error", "error"),
    }

def parse_args():
    p = argparse.ArgumentParser(description="Simple: list per-day, process JSON → Parquet in parallel")
    p.add_argument("--settings", default="settings.json")
    p.add_argument("--columns-yaml", default="columns.yml")
    p.add_argument("--max-workers", type=int, default=min(32, (os.cpu_count() or 8) * 5))
    p.add_argument("--limit", type=int, default=0, help="Cap total files across all days (0 = no cap)")
    return p.parse_args()


def load_config(path: str):
    with open(path, "r", encoding="utf-8") as f:
        y = yaml.safe_load(f)
    cols = y.get("columns", [])
    sess_cols = y.get("session_columns", [])
    if not isinstance(cols, list) or not isinstance(sess_cols, list):
        raise ValueError("columns.yml must have 'columns' and 'session_columns' lists")
    return cols, sess_cols


def to_parquet_bytes(df: pd.DataFrame) -> bytes:
    table = pa.Table.from_pandas(df, preserve_index=False)
    sink = io.BytesIO()
    pq.write_table(table, sink, compression="snappy")
    return sink.getvalue()


def derive_output_name(input_blob_name: str, dst_prefix: str) -> str:
    base = os.path.basename(input_blob_name)
    stem = base[:-5] if base.lower().endswith(".json") else base
    return f"{dst_prefix.rstrip('/')}/{stem}.parquet"


def _month_abbr_en(month_int: int) -> str:
    return calendar.month_abbr[month_int]  # 'Jan', 'Feb', ...


def _date_prefix(d: date) -> str:
    return f"{d.year}/{_month_abbr_en(d.month)}/{d.day:02d}/"  # "YYYY/MMM/dd/"


def _join_prefix(root_prefix: str, date_prefix: str) -> str:
    root = (root_prefix or "").strip("/")
    dp = date_prefix.strip("/")
    return (f"{root}/{dp}" if root else dp) + ("" if dp.endswith("/") else "/")


def _iter_dates(start_str: str, end_str: str) -> Iterable[date]:
    y1, m1, d1 = map(int, start_str.split("-"))
    y2, m2, d2 = map(int, end_str.split("-"))
    start_d = date(y1, m1, d1)
    end_d = date(y2, m2, d2)
    if end_d < start_d:
        raise ValueError("date_range.end < date_range.start")
    cur = start_d
    one = timedelta(days=1)
    while cur <= end_d:
        yield cur
        cur += one


def process_one(blob_name: str,
                src_cc,
                dst_cc,
                columns: List[str],
                session_columns: List[str],
                dst_prefix: str) -> Optional[str]:
    """Return dst blob path on success, 'ERROR::...' on failure, or None if no rows."""
    try:
        raw = download_text(src_cc, blob_name)
        rec = orjson.loads(raw)
        ordered_cols, rows = build_rows(rec, columns, session_columns)
        if not rows:
            return None  # skipped
        df = pd.DataFrame(rows, columns=ordered_cols)
        out = to_parquet_bytes(df)
        dst_blob = derive_output_name(blob_name, dst_prefix)
        upload_bytes(dst_cc, dst_blob, out, overwrite=True)
        return dst_blob
    except Exception as e:
        return f"ERROR::{blob_name}::{e}"


def main():
    args = parse_args()

    # Load settings & auth
    settings = load_settings(args.settings)
    auth_mode = (settings.get("auth", {}).get("mode") or "").lower()

    # connection_string mode sets env var; other modes skip
    apply_auth_env(settings)

    # choose credential if not using connection string
    credential = None
    if auth_mode == "service_principal":
        credential = make_sp_credential(settings["auth"])
    elif auth_mode == "default_credential":
        credential = DefaultAzureCredential()
    # else: connection_string or SAS handled via settings/env in azure_io

    src_cfg = settings.get("source", {})
    dst_cfg = settings.get("destination", {})
    sas = settings.get("_resolved", {}).get("sas_token")

    # Blob clients
    src_cc = make_container_client(
        account_url=src_cfg.get("account_url"),
        container=src_cfg.get("container"),
        credential=credential,
        sas_token=sas
    )
    dst_cc = make_container_client(
        account_url=dst_cfg.get("account_url"),
        container=dst_cfg.get("container"),
        credential=credential,
        sas_token=sas
    )

    # Columns
    columns, session_columns = load_config(args.columns_yaml)

    # Date loop
    dr = src_cfg.get("date_range") or {}
    start_s, end_s = dr.get("start"), dr.get("end")
    if not start_s or not end_s:
        raise ValueError("Please set source.date_range.start and .end (YYYY-MM-DD) in settings.json")

    root_src = src_cfg.get("root_prefix") or ""
    root_dst = dst_cfg.get("root_prefix") or ""

    print(f"Scanning days {start_s} → {end_s}")

    submitted = 0
    successes = 0
    skipped = 0
    failures = 0

    futures_map: Dict = {}

    with ThreadPoolExecutor(max_workers=args.max_workers) as ex:
        # submit everything quickly, then consume as_completed
        for d in _iter_dates(start_s, end_s):
            day_loggers = setup_day_loggers(d)
            day_prefix = _date_prefix(d)
            src_prefix = _join_prefix(root_src, day_prefix)
            dst_prefix = _join_prefix(root_dst, day_prefix)
            print(f"Listing {src_prefix} ...", flush=True)
            try:
                blobs = list(iter_json_blobs(src_cc, prefix=src_prefix))
            except Exception as e:
                print(f"[LIST ERROR] {src_prefix} -> {e}", file=sys.stderr, flush=True)
                continue

            if not blobs:
                print(f"Found 0 files in {src_prefix}")
                continue
            print(f"Found {len(blobs)} files in {src_prefix}")

            # optional cap
            if args.limit and args.limit > 0:
                remaining = args.limit - submitted
                if remaining <= 0:
                    break
                blobs = blobs[:remaining]

            for b in blobs:
                fut = ex.submit(process_one, b, src_cc, dst_cc, columns, session_columns, dst_prefix)
                futures_map[fut] = b
            submitted += len(blobs)

        # consume results with progress
        for fut in tqdm(as_completed(futures_map), total=len(futures_map), unit="file"):
            res = fut.result()
            blob_name = futures_map[fut]
            if res is None:
                skipped += 1
                day_loggers["skipped"].info(f"{blob_name}  reason=no_sessions")
            elif isinstance(res, str) and res.startswith("ERROR::"):
                failures += 1
                msg = res.split("::", 2)[-1]
                day_loggers["error"].info(f"{blob_name}  error={msg}")
                print(res, file=sys.stderr, flush=True)
            else:
                successes += 1
                day_loggers["processed"].info(f"{blob_name}  status=processed")


    print(f"Done. Submitted: {submitted}, Success: {successes}, Skipped: {skipped}, Failed: {failures}", flush=True)
    logging.info(f"SUMMARY {datetime.now()}  success={successes} skipped={skipped} failed={failures}")

if __name__ == "__main__":
    main()
