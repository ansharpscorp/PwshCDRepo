from __future__ import annotations
import os, json, base64
from typing import Dict, Any, Optional
from azure.identity import ClientSecretCredential

def _resolve_secret(value: Optional[str]) -> Optional[str]:
    if not value: return None
    if isinstance(value, str):
        if value.startswith("env:"): return os.getenv(value[4:], None)
        if value.startswith("b64:"):
            try: return base64.b64decode(value[4:]).decode("utf-8")
            except Exception: return None
        return value
    return None

def load_settings(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    auth = cfg.get("auth", {}) or {}
    secrets = cfg.get("secrets", {}) or {}

    cfg["_resolved"] = {
        "connection_string": _resolve_secret(auth.get("connection_string")),
        "account_key": _resolve_secret(secrets.get("account_key")),
        "sas_token": _resolve_secret(secrets.get("sas_token")),
        "client_secret": _resolve_secret(auth.get("client_secret")),
    }
    return cfg

def apply_auth_env(settings: Dict[str, Any]) -> None:
    """Only sets connection string env if mode=connection_string."""
    mode = (settings.get("auth", {}).get("mode") or "").lower()
    if mode == "connection_string":
        conn_str = settings.get("_resolved", {}).get("connection_string")
        if conn_str:
            os.environ["AZURE_STORAGE_CONNECTION_STRING"] = conn_str

def make_sp_credential(auth_cfg: Dict[str, Any]) -> ClientSecretCredential:
    tenant_id = auth_cfg.get("tenant_id")
    client_id = auth_cfg.get("client_id")
    client_secret = _resolve_secret(auth_cfg.get("client_secret"))  # also stored in _resolved
    if not (tenant_id and client_id and client_secret):
        raise ValueError("Service Principal mode needs tenant_id, client_id, client_secret")
    return ClientSecretCredential(tenant_id=tenant_id, client_id=client_id, client_secret=client_secret)
