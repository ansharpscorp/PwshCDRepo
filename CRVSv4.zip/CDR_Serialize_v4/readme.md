# CallRecord JSON → Parquet (simple, parallel, RBAC-ready)

- Reads:  bronze/CDR/YYYY/MMM/dd/*.json
- Writes: gold/Parquet/YYYY/MMM/dd/*.parquet
- 1 row per session (or one null-session row if none)
- `modalities` arrays → "a,b,c"
- Masks `*.phone.id` with last 4 → `****` and **keeps leading '+'**

## Install
python -m venv .venv
# activate venv ...
pip install -r requirements.txt

## Configure auth (choose one)
- Service Principal (RBAC): set `auth.mode="service_principal"` + tenant/client/secret (b64 allowed)
- Connection string: set `auth.mode="connection_string"` + `connection_string` (b64 allowed)
- Default credential: set `auth.mode="default_credential"` (Managed Identity / Azure CLI)

## Run
python main.py --settings settings.json --columns-yaml columns.yml --max-workers 32

## Notes
- If you see transient download errors, try `--max-workers 16` (reduce parallelism).
- Ensure the SP has **Storage Blob Data Contributor** on the storage account(s).

# To encode
python -c "import base64; print(base64.b64encode(b'MY_SECRET_VALUE').decode())"