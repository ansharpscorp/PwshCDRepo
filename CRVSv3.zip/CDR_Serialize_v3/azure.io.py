from __future__ import annotations
import os
from typing import Iterable, Optional
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
from azure.storage.blob import BlobServiceClient, ContainerClient, BlobClient
from azure.core.exceptions import ServiceRequestError, ServiceResponseError

def make_container_client(account_url: str, container: str, credential=None, sas_token: Optional[str] = None) -> ContainerClient:
    """
    Prefers connection string if AZURE_STORAGE_CONNECTION_STRING is set.
    Otherwise uses account_url + credential or + SAS.
    """
    conn_str = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
    if conn_str:
        bsc = BlobServiceClient.from_connection_string(conn_str)
        return bsc.get_container_client(container)
    if sas_token:
        sep = "&" if "?" in account_url else "?"
        bsc = BlobServiceClient(account_url=f"{account_url}{sep}{sas_token}")
        return bsc.get_container_client(container)
    bsc = BlobServiceClient(account_url=account_url, credential=credential)
    return bsc.get_container_client(container)

def iter_json_blobs(container_client: ContainerClient, prefix: Optional[str] = None) -> Iterable[str]:
    for blob in container_client.list_blobs(name_starts_with=prefix):
        if blob.name.lower().endswith(".json"):
            yield blob.name

@retry(reraise=True, stop=stop_after_attempt(5),
       wait=wait_exponential(multiplier=0.5, min=0.5, max=8),
       retry=retry_if_exception_type((ServiceRequestError, ServiceResponseError)))
def download_text(container_client: ContainerClient, blob_name: str) -> bytes:
    bc: BlobClient = container_client.get_blob_client(blob_name)
    downloader = bc.download_blob(max_concurrency=8)
    return downloader.readall()

@retry(reraise=True, stop=stop_after_attempt(5),
       wait=wait_exponential(multiplier=0.5, min=0.5, max=8),
       retry=retry_if_exception_type((ServiceRequestError, ServiceResponseError)))
def upload_bytes(container_client: ContainerClient, blob_name: str, data: bytes, overwrite=True) -> None:
    bc: BlobClient = container_client.get_blob_client(blob_name)
    bc.upload_blob(data, overwrite=overwrite)
