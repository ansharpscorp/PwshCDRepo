# CallRecord JSON → Parquet (parallel, mirrored, masked, logged)

## What it does
- Reads from: `bronze/CDR/YYYY/MMM/dd/*.json`
- Writes to:  `gold/Parquet/YYYY/MMM/dd/*.parquet`
- One row per session (or one null-session row)
- Masks `*.phone.id` (last 4 digits → `****`)
- Flattens list fields (e.g., `modalities` → "audio,video")
- Writes 3 logs per day in `logs/YYYY_Mon_dd/`

## Install
```bash
python -m venv .venv
# activate venv...
pip install -r requirements.txt
