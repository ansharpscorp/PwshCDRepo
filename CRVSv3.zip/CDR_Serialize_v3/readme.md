# CallRecord JSON → Parquet (robust listing)

## What it does
- Reads:  bronze/CDR/YYYY/MMM/dd/*.json
- Writes: gold/Parquet/YYYY/MMM/dd/*.parquet
- Explodes sessions → rows; modalities lists → "a,b,c"; masks *.phone.id → ****
- Per-day JSONL logs: processed, skipped, error
- **Robust blob listing**: paged, with timeouts, errors logged, and next day continues

## Install
python -m venv .venv
# activate venv
pip install -r requirements.txt

## Configure
- settings.json: accounts, containers, prefixes, date range, and auth (connection string b64 recommended)
- columns.yml: fields to flatten (dot-paths)

## Run
python main.py --settings settings.json --columns-yaml columns.yml --max-workers 64 --verbose

### Listing knobs (if you see stalls)
- --list-timeout 30      # shorten per-page timeout
- --list-page-size 500   # larger or smaller pages
- --list-max-pages 10    # cap pages per day (for testing)

Console shows:
- "Listing CDR/2025/Oct/04/ …" then "Found N files …"
- Progress bar for file processing
