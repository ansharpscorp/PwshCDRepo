# CallRecord JSON → Parquet

## Install
python -m venv .venv
# activate venv
pip install -r requirements.txt

## Configure
- settings.json: set account urls, containers, prefixes, date range, and auth
- columns.yml: choose fields

## Run
python main.py --settings settings.json --columns-yaml columns.yml --max-workers 64 --verbose

- progress bar shows throughput
- logs per day: logs/YYYY_Mon_dd/{processed,skipped,error}.log
