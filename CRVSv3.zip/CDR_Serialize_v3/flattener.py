from __future__ import annotations
from typing import Any, Dict, List, Tuple
import copy
import re

def _get_by_path(obj: Any, path: str, default=None):
    """
    Safely fetch nested value via dotted path 'a.b.c'.
    Returns None if any intermediate key missing.
    """
    cur = obj
    for part in path.split("."):
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            return default
    return cur

def _mask_phone_number(value: Any) -> Any:
    """
    Mask the last 4 digits of any phone number with asterisks.
    Examples:
        9876543210      -> 987654****
        +919876543210   -> 919876****
        1234            -> ****
        123             -> ***
    """
    if not isinstance(value, str):
        return value
    digits = re.sub(r"\D", "", value)
    if not digits:
        return value
    mask_len = 4 if len(digits) > 4 else len(digits)
    return digits[:-mask_len] + ("*" * mask_len)

def normalize_name(path: str) -> str:
    """Replace '.' with '_' for Parquet column names."""
    return path.replace(".", "_")

def _mask_if_phone(field_name: str, value: Any) -> Any:
    """Detect phone.id or *_phone_id fields and apply masking."""
    if field_name.endswith("_phone_id") or "phone.id" in field_name:
        return _mask_phone_number(value)
    return value

def _format_value(field_name: str, value: Any) -> Any:
    """
    Normalize field values:
      - Convert lists (e.g., modalities) to comma-separated strings.
      - Apply phone masking when required.
    """
    if isinstance(value, list):
        value = ",".join(str(v) for v in value if v is not None)
    value = _mask_if_phone(field_name, value)
    return value

def build_rows(call_json: Dict[str, Any],
               top_columns: List[str],
               session_columns: List[str]) -> Tuple[List[str], List[Dict[str, Any]]]:
    """
    One row per sessions[] element; if no sessions, one row with sessions.* = None.
    Adds masking for phone.id and flattens list fields like modalities.
    """
    col_order: List[str] = []
    col_map: Dict[str, str] = {}

    for p in top_columns + session_columns:
        if p not in col_map:
            col_map[p] = normalize_name(p)
            col_order.append(col_map[p])

    base_row: Dict[str, Any] = {}
    for p in top_columns:
        val = _get_by_path(call_json, p, None)
        base_row[col_map[p]] = _format_value(p, val)

    sessions = call_json.get("sessions") or []
    rows: List[Dict[str, Any]] = []

    if not isinstance(sessions, list) or len(sessions) == 0:
        row = copy.copy(base_row)
        for sp in session_columns:
            row[col_map[sp]] = None
        rows.append(row)
        return col_order, rows

    for sess in sessions:
        row = copy.copy(base_row)
        for sp in session_columns:
            if sp.startswith("sessions.") and isinstance(sess, dict):
                inner = sp[len("sessions."):]
                val = _get_by_path(sess, inner, None)
            else:
                val = _get_by_path(call_json, sp, None)
            row[col_map[sp]] = _format_value(sp, val)
        rows.append(row)

    return col_order, rows
