callrecord-etl/
├─ main.py
├─ flattener.py
├─ azure_io.py
├─ settings_loader.py
├─ log_utils.py
├─ columns.yml
├─ settings.json
├─ requirements.txt
└─ README.md