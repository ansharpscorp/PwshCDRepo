from __future__ import annotations
import os
import json
import logging
from datetime import datetime, date

class JsonLineFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        base = {
            "ts": datetime.utcnow().isoformat(timespec="milliseconds") + "Z",
            "level": record.levelname,
        }
        event = getattr(record, "event", None)
        if isinstance(event, dict):
            base.update(event)
        else:
            base["message"] = record.getMessage()
        return json.dumps(base, ensure_ascii=False)

class DayLoggers:
    def __init__(self, processed: logging.Logger, skipped: logging.Logger, error: logging.Logger):
        self.processed = processed
        self.skipped = skipped
        self.error = error

def _make_logger(path: str) -> logging.Logger:
    logger = logging.getLogger(path)
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fh = logging.FileHandler(path, encoding="utf-8")
    fh.setLevel(logging.INFO)
    fh.setFormatter(JsonLineFormatter())
    logger.addHandler(fh)
    return logger

def _day_tag(d: date) -> str:
    return d.strftime("%Y_%b_%d")  # e.g., 2025_Oct_04 (month in English abbr)

def setup_day_loggers(d: date) -> DayLoggers:
    tag = _day_tag(d)
    base_dir = os.path.join("logs", tag)
    processed_path = os.path.join(base_dir, "processed.log")
    skipped_path   = os.path.join(base_dir, "skipped.log")
    error_path     = os.path.join(base_dir, "error.log")
    return DayLoggers(
        processed=_make_logger(processed_path),
        skipped=_make_logger(skipped_path),
        error=_make_logger(error_path),
    )

def day_loggers_from_prefix(day_prefix: str) -> DayLoggers:
    """
    Recreate loggers from a prefix like 'YYYY/Mon/dd/'.
    """
    try:
        parts = day_prefix.strip("/").split("/")
        y, mon, dd = int(parts[0]), parts[1], int(parts[2])
        dt = datetime.strptime(f"{y}-{mon}-{dd:02d}", "%Y-%b-%d").date()
    except Exception:
        dt = datetime.utcnow().date()
    return setup_day_loggers(dt)

def jlog(logger: logging.Logger, level: int, event_type: str, **fields):
    payload = {"event": event_type}
    payload.update(fields)
    logger._log(level, msg="", args=(), extra={"event": payload})
