import os
from datetime import datetime, timedelta, date

from runtime_ctx import RuntimeCtx
from logging_utils import setup_logging, get_logger
from yaml_utils import load_columns_yaml
from export_logic import ensure_required_columns, load_query_text, export_one_day
from metrics import write_local_metrics

log = get_logger("main")

def daterange(d0: date, d1: date):
    cur = d0
    while cur <= d1:
        yield cur
        cur += timedelta(days=1)

def main():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    ctx = RuntimeCtx(root)
    cfg = ctx.config

    logcfg = cfg.get("logging", {})
    setup_logging(
        app_name="cqd_exporter",
        log_dir=os.path.join(root, logcfg.get("log_dir", "_logs")),
        level=logcfg.get("level", "INFO"),
        rotate_megabytes=int(logcfg.get("rotate_megabytes", 20)),
        backups=int(logcfg.get("backups", 7))
    )

    start = datetime.strptime(cfg["window"]["start_date"], "%Y-%m-%d").date()
    end   = datetime.strptime(cfg["window"]["end_date"], "%Y-%m-%d").date()
    days = [d for d in daterange(start, end)]
    log.info(f"Window: {start} → {end} ({len(days)} day(s))")

    date_col = cfg["source"]["date_column"]
    conf_col = cfg["source"]["conference_id_column"]
    cols = load_columns_yaml(os.path.join(root, "columns.yml"))
    cols = ensure_required_columns(cols, date_col, conf_col)

    qfile = os.path.join(root, cfg["source"]["query_file"])
    base_query = load_query_text(qfile)

    conn = ctx.sql_conn()
    fs   = ctx.adls_fs()

    all_metrics = []
    for the_day in days:
        log.info(f"Exporting {the_day} ...")
        metrics = export_one_day(
            conn=conn, fs=fs, base_output=cfg["export"]["output_base"].rstrip("/"),
            base_query=base_query, date_col=date_col, conf_col=conf_col, select_cols=cols,
            the_day=the_day, batch_conf_ids=int(cfg["export"]["batch_conference_ids"]),
            compression=cfg["export"].get("compression", "snappy"), arraysize=ctx.arraysize
        )
        log.info(f"{the_day} -> files={len(metrics)}")
        all_metrics.extend(metrics)

    mc = cfg.get("metrics", {})
    if mc.get("write_local_csv", True) and all_metrics:
        out = write_local_metrics(os.path.join(root, mc.get("local_folder", "_metrics")), all_metrics)
        log.info(f"Metrics written: {out}")

    conn.close()
    log.info("✅ Completed.")

if __name__ == "__main__":
    main()
