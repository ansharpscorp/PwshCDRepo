import pyodbc
from azure.identity import ClientSecretCredential

_SQL_COPT_SS_ACCESS_TOKEN = 1256  # SQL Server-specific attribute

def _aad_access_token(tenant_id: str, client_id: str, client_secret: str) -> bytes:
    """Get Azure AD token for Azure SQL; return UTF-16-LE with a terminating null."""
    scope = "https://database.windows.net/.default"
    raw = ClientSecretCredential(tenant_id, client_id, client_secret).get_token(scope).token
    return bytes(raw, "utf-16-le") + b"\x00"

def _base_conn_str(server: str, database: str, driver: str, timeout_seconds: int) -> str:
    # No Authentication= here; token injected via attrs_before.
    return (
        f"Driver={driver};"
        f"Server=tcp:{server},1433;"
        f"Database={database};"
        "Encrypt=yes;"
        "TrustServerCertificate=no;"
        f"Timeout={timeout_seconds};"
    )

def connect_odbc(server: str, database: str, driver: str,
                 tenant_id: str, client_id: str, client_secret: str,
                 timeout_seconds: int = 0):
    pyodbc.pooling = False
    base = _base_conn_str(server, database, driver, timeout_seconds)

    # Try token injection
    try:
        token = _aad_access_token(tenant_id, client_id, client_secret)
        conn = pyodbc.connect(base, attrs_before={_SQL_COPT_SS_ACCESS_TOKEN: token})
        conn.autocommit = True
        return conn
    except pyodbc.Error:
        pass

    # Fallback: Service Principal auth by the driver
    spn = (
        base +
        f"Authentication=ActiveDirectoryServicePrincipal;"
        f"Authority=https://login.microsoftonline.com/{tenant_id};"
        f"Uid={client_id};"
        f"Pwd={client_secret};"
    )
    conn = pyodbc.connect(spn)
    conn.autocommit = True
    return conn
