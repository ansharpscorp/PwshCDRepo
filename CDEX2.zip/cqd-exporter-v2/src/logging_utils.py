import logging, os, sys
from logging.handlers import RotatingFileHandler

_LEVELS = {"DEBUG": logging.DEBUG, "INFO": logging.INFO, "WARNING": logging.WARNING,
           "ERROR": logging.ERROR, "CRITICAL": logging.CRITICAL}

def setup_logging(app_name: str, log_dir: str, level: str = "INFO",
                  rotate_megabytes: int = 20, backups: int = 7):
    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, f"{app_name}.log")

    logger = logging.getLogger()
    logger.handlers.clear()
    logger.setLevel(_LEVELS.get(level.upper(), logging.INFO))

    fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(processName)s | %(name)s | %(message)s",
                            datefmt="%Y-%m-%d %H:%M:%S")

    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(fmt)
    logger.addHandler(sh)

    fh = RotatingFileHandler(log_path, maxBytes=rotate_megabytes * 1024 * 1024, backupCount=backups, encoding="utf-8")
    fh.setFormatter(fmt)
    logger.addHandler(fh)

    logging.getLogger(__name__).info(f"Logging to {log_path} (level={level})")

def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)
