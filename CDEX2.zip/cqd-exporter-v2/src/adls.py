from azure.identity import ClientSecretCredential
import fsspec

def get_abfs_filesystem(account_name: str, tenant_id: str, client_id: str, client_secret: str):
    cred = ClientSecretCredential(tenant_id=tenant_id, client_id=client_id, client_secret=client_secret)
    fs = fsspec.filesystem("abfs", account_name=account_name, credential=cred)
    return fs
