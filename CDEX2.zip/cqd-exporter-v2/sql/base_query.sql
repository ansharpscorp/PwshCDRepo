/*
  This file should NOT start with a CTE (WITH ...). Keep it a simple SELECT.
  If your complex logic uses CTEs, create a view (e.g., dbo.v_CQD_Base) and select from it here.
*/
SELECT *
FROM dbo.v_CQD_Base
WHERE [Date] BETWEEN @p_start AND @p_end;
