python -m src.main --settings config/settings.json --secrets config/secrets.json --columns config/columns.yml
