from typing import Dict, List, Union, Optional, Any
import pyarrow as pa
import pyarrow.parquet as pq
from .logger import info

ColumnSpec = Union[str, Dict[str, object]]

# ---------- raw JSON path helpers ----------
def _as_list(x):
    if isinstance(x, list): return x
    if x is None or x == "": return []
    return [x]

def _get_path(obj: Any, dotted: str):
    """
    Resolve dotted path like 'a.b[0].c' safely over dict/list.
    Supports [index] for arrays. Returns None if path is invalid.
    """
    if obj is None or dotted is None: return None
    cur = obj
    parts = [p for p in dotted.replace("]", "").split(".")]
    for part in parts:
        if part == "": continue
        while "[" in part:
            key, idx = part.split("[", 1)
            if key:
                if not isinstance(cur, dict) or key not in cur: return None
                cur = cur[key]
            try:
                i = int(idx)
            except Exception:
                return None
            if not isinstance(cur, list): return None
            if i < 0 or i >= len(cur): return None
            cur = cur[i]
            part = ""
        if part:
            if not isinstance(cur, dict) or part not in cur: return None
            cur = cur[part]
    return cur

def _project_items(items: List[Any], subpath: Optional[str]) -> List[Any]:
    out: List[Any] = []
    for it in _as_list(items):
        if subpath:
            v = _get_path(it, subpath)
            if v is not None: out.append(v)
        else:
            out.append(it)
    return out

# ---------- apply a single column spec ----------
def _apply_column_spec(row: Dict, spec: ColumnSpec) -> Dict:
    if isinstance(spec, str):
        return {spec: row.get(spec)}

    name = spec.get("name")
    if not name:
        return {}

    # rename from flat
    if "from" in spec:
        return {name: row.get(spec["from"])}

    # coalesce flat
    if "coalesce" in spec:
        for key in spec["coalesce"]:
            val = row.get(key)
            if val is not None:
                return {name: val}
        return {name: spec.get("default")}

    raw = row.get("__raw")

    # path into raw
    if "path" in spec:
        val = _get_path(raw, spec["path"])
        if "join" in spec:
            delimiter = spec.get("join") or ";"
            subpath = spec.get("subpath")
            values = _project_items(_as_list(val), subpath)
            values = [str(v) for v in values if v is not None and str(v) != ""]
            return {name: delimiter.join(values) if values else None}
        return {name: val}

    # count_of array at path
    if "count_of" in spec:
        arr = _get_path(raw, spec["count_of"])
        return {name: len(_as_list(arr))}

    # first_of array at path (optional subpath)
    if "first_of" in spec:
        arr = _get_path(raw, spec["first_of"])
        subpath = spec.get("subpath")
        values = _project_items(_as_list(arr), subpath)
        return {name: (values[0] if values else None)}

    return {name: None}

def _filter_columns(rows: List[Dict], columns: Optional[List[ColumnSpec]]) -> List[Dict]:
    if not columns:
        return [{k: v for k, v in r.items() if k != "__raw"} for r in rows]
    out: List[Dict] = []
    for r in rows:
        new_r: Dict = {}
        for spec in columns:
            new_r.update(_apply_column_spec(r, spec))
        out.append(new_r)
    return out

def write_parquet_one_file(fs_out, out_path: str, rows: List[Dict],
                           columns: Optional[List[ColumnSpec]] = None,
                           compression: str = "snappy"):
    filtered = _filter_columns(rows, columns)
    table = pa.Table.from_pylist(filtered)
    parent = "/".join(out_path.split("/")[:-1])
    try:
        fs_out.makedirs(parent, exist_ok=True)
    except Exception:
        pass
    with fs_out.open(out_path, "wb") as f:
        pq.write_table(table, f, compression=compression)
    info("Saved parquet", file=out_path, rows=len(filtered))
