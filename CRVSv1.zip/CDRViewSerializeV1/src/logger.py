import sys, json, time, os, threading

RUN_ID  = os.environ.get("RUN_ID", time.strftime("%Y%m%d_%H%M%S"))
LOG_DIR = os.environ.get("LOG_DIR") or "logs"
os.makedirs(LOG_DIR, exist_ok=True)
LOGFILE = os.path.join(LOG_DIR, f"run_{RUN_ID}.log")
_lock = threading.Lock()

def _emit(line: str):
    print(line, file=sys.stderr)
    try:
        with _lock:
            with open(LOGFILE, "a", encoding="utf-8") as f:
                f.write(line + "\n")
    except Exception:
        pass

def log(level, msg, **kv):
    payload = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "level": level, "msg": msg, "run_id": RUN_ID}
    if kv: payload.update(kv)
    _emit(json.dumps(payload, ensure_ascii=False))

def info(msg, **kv): log("INFO", msg, **kv)
def warn(msg, **kv): log("WARN", msg, **kv)
def err(msg,  **kv): log("ERROR", msg, **kv)
def get_logfile_path(): return LOGFILE
