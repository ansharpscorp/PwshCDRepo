from typing import List, Iterable
import json, calendar
import fsspec
from urllib.parse import urlparse
from datetime import date, timedelta
import yaml
from .logger import info

# ---------- load helpers ----------
def load_json(path: str):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def load_yaml(path: str):
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

# ---------- fs helpers ----------
def is_abfs_uri(uri: str) -> bool:
    scheme = urlparse((uri or "").strip()).scheme.lower()
    return scheme in ("abfs", "abfss")

def get_fs_for_path(path_root: str, secrets: dict):
    if is_abfs_uri(path_root):
        return fsspec.filesystem(
            "abfss",
            account_name=secrets["account_name"],
            tenant_id=secrets["tenant_id"],
            client_id=secrets["client_id"],
            client_secret=secrets["client_secret"],
        )
    return fsspec.filesystem("file")

def join_uri(root: str, *parts: str) -> str:
    base = (root or "").rstrip("/")
    tail = "/".join((p or "").strip("/") for p in parts if p is not None)
    return f"{base}/{tail}".rstrip("/")

def iter_files(fs, root: str, recursive: bool, include_ext: List[str]) -> Iterable[str]:
    """
    Yield file paths under `root`. Robust on ABFSS: try find(), ls(), then glob().
    """
    root = (root or "").rstrip("/")
    include_ext = [e.lower() for e in (include_ext or [])]

    def want(p: str) -> bool:
        if fs.isdir(p): return False
        if not include_ext: return True
        pl = p.lower()
        return any(pl.endswith(ext) for ext in include_ext)

    listed = False
    if recursive:
        try:
            for p in fs.find(root):
                if want(p): yield p
            listed = True
        except Exception:
            pass
    if not listed:
        try:
            for p in fs.ls(root, detail=False):
                if want(p): yield p
            listed = True
        except Exception:
            pass
    if not listed:
        pattern = root + ("/**/*" if recursive else "/*")
        for p in fs.glob(pattern):
            if want(p) and not fs.isdir(p):
                yield p

    info("Listing complete", root=root, recursive=recursive)

# ---------- date helpers ----------
def month_mmm(d: date) -> str:
    return calendar.month_abbr[d.month]  # 'Sep', 'Aug', ...

def day_dd(d: date) -> str:
    return f"{d.day:02d}"

def daterange(start: date, end: date):
    cur = start
    while cur <= end:
        yield cur
        cur += timedelta(days=1)

# ---------- path helpers ----------
def to_relative_path(base_root: str, full_path: str) -> str:
    b = base_root.rstrip("/") + "/"
    if full_path.startswith(b):
        return full_path[len(b):]
    if full_path.lower().startswith(b.lower()):
        return full_path[len(b):]
    return full_path.split("/")[-1]

def replace_ext(path: str, new_ext: str) -> str:
    i = path.rfind(".")
    if i == -1 or "/" in path[i:]:
        return path + new_ext
    return path[:i] + new_ext
