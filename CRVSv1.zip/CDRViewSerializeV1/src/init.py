# Allow running as: python -m src.main
