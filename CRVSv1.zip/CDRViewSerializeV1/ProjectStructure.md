json2parquet-1to1/
├─ config/
│  ├─ secrets.json
│  ├─ settings.json
│  └─ columns.yml
├─ src/
│  ├─ __init__.py
│  ├─ logger.py
│  ├─ io_utils.py
│  ├─ flattener.py
│  ├─ writer.py
│  └─ main.py               # ← parallel reading/writing
├─ requirements.txt
└─ README.md
