# JSON → Parquet (1:1) with Session Participants — Parallel ADLS Gen2

- Reads only dates in `start_date..end_date` from `.../cdr/YYYY/MMM/dd/` (month is 3-letter English string: Jan..Dec)
- Processes many files **in parallel** (configurable `concurrency`)
- For each JSON: writes **one Parquet** with the **same relative path/name** (just `.parquet`)
- Emits **one row per (session × participant)** with unified identity (`user` or `phone`)
- If a call has **no sessions**, still emits one row with session/identity fields `null`
- Column selection is driven by `config/columns.yml` (simple, rename, coalesce, and JSON-path rules)

## Install
```bash
pip install -r requirements.txt
