import requests, time, json

with open('config.json') as f:
    config = json.load(f)

TOKEN_URL = f"https://login.microsoftonline.com/{config['tenant_id']}/oauth2/v2.0/token"
_token_cache = {"token": None, "expiry": 0}

def get_token():
    if _token_cache["token"] and _token_cache["expiry"] - time.time() > 60:
        return _token_cache["token"]

    data = {
        'client_id': config['client_id'],
        'scope': 'https://graph.microsoft.com/.default',
        'client_secret': config['client_secret'],
        'grant_type': 'client_credentials'
    }
    response = requests.post(TOKEN_URL, data=data)
    response.raise_for_status()
    result = response.json()
    _token_cache["token"] = result['access_token']
    _token_cache["expiry"] = time.time() + int(result['expires_in'])
    return _token_cache["token"]