import requests, json, time
from concurrent.futures import ThreadPoolExecutor
from token_manager import get_token
from utils import write_to_csv, log_info

def fetch_cdr(start, end):
    token = get_token()
    url = f"https://graph.microsoft.com/beta/communications/callRecords?"           f"$filter=startDateTime ge {start} and endDateTime le {end}"
    headers = {'Authorization': f'Bearer {token}'}
    all_records = []

    while url:
        resp = requests.get(url, headers=headers)
        if resp.status_code == 429:
            time.sleep(5)
            continue
        resp.raise_for_status()
        data = resp.json()
        records = data.get('value', [])
        for rec in records:
            all_records.append({
                "id": rec.get("id"),
                "type": rec.get("type"),
                "lastModifiedDateTime": rec.get("lastModifiedDateTime"),
                "startDateTime": rec.get("startDateTime"),
                "endDateTime": rec.get("endDateTime")
            })
        url = data.get('@odata.nextLink', None)

    log_info(f"Fetched {len(all_records)} records from {start} to {end}")
    return all_records

def process_intervals(start_date, start_hour, end_hour):
    intervals = []
    for hour in range(start_hour, end_hour):
        for minute in [0, 15, 30, 45]:
            start = f"{start_date}T{hour:02d}:{minute:02d}:00Z"
            end_min = minute + 15
            end_hour_adj = hour + (end_min // 60)
            end_min = end_min % 60
            end = f"{start_date}T{end_hour_adj:02d}:{end_min:02d}:00Z"
            intervals.append((start, end))
    return intervals

def run_parallel_download(date, start_hour, end_hour):
    intervals = process_intervals(date, start_hour, end_hour)
    all_data = []

    with ThreadPoolExecutor(max_workers=4) as executor:
        results = executor.map(lambda args: fetch_cdr(*args), intervals)
        for res in results:
            all_data.extend(res)

    write_to_csv(all_data)