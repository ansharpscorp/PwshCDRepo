import argparse
from downloader import run_parallel_download

parser = argparse.ArgumentParser()
parser.add_argument("--date", required=True, help="Date in YYYY-MM-DD")
parser.add_argument("--start", type=int, required=True, help="Start hour (0-23)")
parser.add_argument("--end", type=int, required=True, help="End hour (1-24)")
args = parser.parse_args()

run_parallel_download(args.date, args.start, args.end)