import csv, json

with open('config.json') as f:
    config = json.load(f)

def write_to_csv(data):
    keys = ["id", "type", "lastModifiedDateTime", "startDateTime", "endDateTime"]
    with open(config['output_csv'], 'w', newline='') as output_file:
        dict_writer = csv.DictWriter(output_file, fieldnames=keys)
        dict_writer.writeheader()
        dict_writer.writerows(data)

def log_info(message):
    print(f"[INFO] {message}")