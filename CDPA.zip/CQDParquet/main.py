import argparse
import asyncio
import json
import yaml
import multiprocessing
import pandas as pd
from concurrent.futures import ProcessPoolExecutor, as_completed
from sqlalchemy import create_engine
from io_handler_async import upload_all_async
from processor import enrich_call_data
from utils import generate_date_range
from logger import get_logger
from tqdm import tqdm

def get_sql_engine(cfg):
    db = cfg["database"]
    conn_str = f"mssql+pyodbc://{db['username']}:{db['password']}@{db['server']}/{db['database']}?driver={db['driver']}"
    return create_engine(conn_str, fast_executemany=True)

def read_sql_table(engine, query):
    return pd.read_sql(query, engine)

def process_day(date_str, cfg, user_df, network_df):
    """Per-day parallel worker for CPU-bound processing."""
    from processor import enrich_call_data
    from sqlalchemy import create_engine

    logger = get_logger()
    try:
        engine = get_sql_engine(cfg)
        query = f"""
        SELECT * FROM {cfg['tables']['call_data']}
        WHERE CONVERT(date, [{cfg['date_column']}]) = '{pd.to_datetime(date_str).strftime('%Y-%m-%d')}'
        """
        call_df = read_sql_table(engine, query)
        if call_df.empty:
            return None, date_str, "No data"

        enriched = enrich_call_data(call_df, user_df, network_df)
        return enriched, date_str, "Success"
    except Exception as e:
        return None, date_str, f"Failed: {e}"

async def orchestrate_async_uploads(results, cfg, logger):
    """Runs all ADLS uploads asynchronously with tqdm progress."""
    tasks = []
    for df, date_str, status in results:
        if df is not None:
            tasks.append({"df": df, "cfg": cfg, "date_str": date_str, "logger": logger})
        else:
            logger.warning(f"⚠️ Skipped {date_str} ({status})")

    if not tasks:
        logger.warning("No data to upload.")
        return

    logger.info(f"🚀 Starting async uploads for {len(tasks)} days")
    await upload_all_async(tasks, concurrency=cfg.get("upload_concurrency", 5))
    logger.info("✅ All uploads completed")

def main(start_date, end_date):
    logger = get_logger()
    logger.info("🚀 Parallel + Async Teams Call Analysis Job Started")

    with open("config.json") as f:
        cfg = json.load(f)
    with open("columns.yml") as f:
        cols = yaml.safe_load(f)["columns"]

    engine = get_sql_engine(cfg)
    user_df = read_sql_table(engine, f"SELECT * FROM {cfg['tables']['user_data']}")
    network_df = read_sql_table(engine, f"SELECT * FROM {cfg['tables']['network_data']}")

    date_list = generate_date_range(start_date, end_date)
    max_workers = min(len(date_list), multiprocessing.cpu_count())

    results = []
    logger.info(f"🧩 Using {max_workers} CPU workers")

    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(process_day, d, cfg, user_df, network_df): d for d in date_list}
        for future in tqdm(as_completed(futures), total=len(futures), desc="Processing Daily Data"):
            res = future.result()
            results.append(res)
            logger.info(f"🧩 Processed {res[1]} — {res[2]}")

    asyncio.run(orchestrate_async_uploads(results, cfg, logger))
    logger.info("🏁 All processing and uploads completed")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate and upload daily Teams parquet files.")
    parser.add_argument("--startDate", required=True, help="Start date in YYYY-MM-DD")
    parser.add_argument("--endDate", required=True, help="End date in YYYY-MM-DD")
    args = parser.parse_args()

    main(args.startDate, args.endDate)
