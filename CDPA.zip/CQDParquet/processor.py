import pandas as pd
import numpy as np

def enrich_call_data(call_df, user_df, network_df):
    merged = call_df.copy()
    merged["Date"] = pd.to_datetime(merged["Date"])
    user_emails = user_df["Email"].unique()

    # --- Call Type ---
    def call_type(row):
        st = row["Session Type"]
        if st == "P2P":
            if row["First UserType"] == "User" and row["First Is Caller"] and row["First UPN"] in user_emails:
                return "Outbound"
            if row["Second UPN"] in user_emails:
                return "Inbound"
            if pd.isna(row["First UPN"]) and pd.notna(row["First Phone Number"]) and row["Second UPN"] in user_emails:
                return "Inbound"
            if pd.isna(row["Second UPN"]) and pd.notna(row["Second Phone Number"]) and row["First UPN"] in user_emails:
                return "Outbound"
        elif st == "Conf":
            domains = merged.groupby("Conference Id")["Second Domain"].nunique()
            if domains.get(row["Conference Id"], 0) > 1 or (pd.isna(row["Second UPN"]) and pd.notna(row["Second Phone Number"])):
                return "Conference"
        return None

    # --- Participant Type ---
    def participant_type(row):
        st = row["Session Type"]
        if st == "Conf":
            if pd.isna(row["Second UPN"]) and pd.notna(row["Second Phone Number"]):
                return "External"
            return "Internal"
        elif st == "P2P":
            if (pd.isna(row["First UPN"]) and pd.notna(row["First Phone Number"])) or (pd.isna(row["Second UPN"]) and pd.notna(row["Second Phone Number"])):
                return "External"
            return "Internal"
        return None

    merged["Call Type"] = merged.apply(call_type, axis=1)
    merged["Participant Type"] = merged.apply(participant_type, axis=1)

    # --- Subnet Matching ---
    def subnet_match(row):
        st = row["Session Type"]
        subnet = None
        if st == "P2P":
            if row["First UserType"] == "User" and row["First UPN"] in user_emails:
                subnet = row["First Subnet"]
            elif row["Second UPN"] in user_emails:
                subnet = row["Second Subnet"]
        elif st == "Conf":
            if row["Second UPN"] in user_emails:
                subnet = row["Second Subnet"]

        if subnet in list(network_df["Subnet"]):
            match = network_df[network_df["Subnet"] == subnet].iloc[0]
            return pd.Series({
                "Subnet Type": "Office",
                "Subnet Building": match["Building"],
                "Subnet Country": match["Country"],
                "Subnet Region": match["Region"]
            })
        else:
            return pd.Series({
                "Subnet Type": "Unknown",
                "Subnet Building": None,
                "Subnet Country": None,
                "Subnet Region": None
            })

    subnet_info = merged.apply(subnet_match, axis=1)
    merged = pd.concat([merged, subnet_info], axis=1)

    # --- Aggregate ---
    agg_df = merged.groupby([
        "Conference Id", "Session Type", "Call Type", "Participant Type",
        "Subnet Type", "Subnet Building", "Subnet Country", "Subnet Region"
    ]).agg({
        "Audio Stream Count": "sum",
        "Audio Poor Stream Count": "sum",
        "Avg Jitter": "mean",
        "Avg Jitter Max": "mean"
    }).reset_index()

    agg_df["Total Participants"] = merged.groupby("Conference Id")["Conference Id"].transform("count").values
    agg_df["Network Connection Details"] = merged["First Network Connection Detail"].combine_first(merged["Second Network Connection Detail"])
    agg_df["Endpoint Name"] = merged["First Endpoint"].combine_first(merged["Second Endpoint"])

    result = agg_df.merge(user_df, how="cross")

    return result[[
        "Email", "Name", "Department", "Conference Id", "Session Type",
        "Call Type", "Participant Type", "Total Participants",
        "Network Connection Details", "Endpoint Name",
        "Audio Stream Count", "Audio Poor Stream Count",
        "Avg Jitter", "Avg Jitter Max",
        "Subnet Type", "Subnet Building", "Subnet Country", "Subnet Region"
    ]]
