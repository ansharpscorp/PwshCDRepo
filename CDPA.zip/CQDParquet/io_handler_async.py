import pandas as pd
import io
import asyncio
from azure.storage.blob.aio import BlobServiceClient
from azure.core.exceptions import AzureError
from tqdm.asyncio import tqdm_asyncio

async def upload_to_adls_async(df, cfg, date_str, logger, sem):
    """Upload one parquet file asynchronously with concurrency limit."""
    adls = cfg["adls"]
    year = date_str[:4]
    month = date_str[4:6]
    file_name = f"Parquet_{date_str}.parquet"
    blob_path = f"{adls['folder']}/{year}/{month}/{file_name}"

    try:
        buffer = io.BytesIO()
        df.to_parquet(buffer, index=False, engine="pyarrow", compression="snappy")
        buffer.seek(0)

        async with sem:
            async with BlobServiceClient(
                f"https://{adls['account_name']}.blob.core.windows.net",
                credential=adls["account_key"]
            ) as service_client:
                blob_client = service_client.get_blob_client(
                    container=adls["container"], blob=blob_path
                )
                await blob_client.upload_blob(buffer.getvalue(), overwrite=True)

        logger.info(f"✅ Uploaded (async): {blob_path} ({len(df)} rows)")
        return True
    except AzureError as e:
        logger.error(f"❌ Azure upload failed for {blob_path}: {e}")
        return False
    except Exception as e:
        logger.error(f"❌ General error uploading {blob_path}: {e}")
        return False


async def upload_all_async(tasks, concurrency=5):
    """Run multiple uploads concurrently with tqdm progress bar."""
    sem = asyncio.Semaphore(concurrency)
    total = len(tasks)

    async def run_task(task):
        return await upload_to_adls_async(**task, sem=sem)

    results = []
    for result in tqdm_asyncio.gather(*(run_task(t) for t in tasks), total=total, desc="Uploading to ADLS"):
        results.append(result)
    return results
