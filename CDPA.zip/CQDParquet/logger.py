import logging
from datetime import datetime
from pathlib import Path
from multiprocessing import Lock

_log_lock = Lock()

def get_logger():
    log_dir = Path("_Logs")
    log_dir.mkdir(exist_ok=True)
    log_file = log_dir / f"Logs_{datetime.now().strftime('%Y%m%d')}.log"

    logger = logging.getLogger("TeamsLogger")
    if not logger.handlers:
        logger.setLevel(logging.INFO)
        formatter = logging.Formatter("%(asctime)s | %(processName)s | %(levelname)s | %(message)s")

        fh = logging.FileHandler(log_file, encoding="utf-8")
        fh.setFormatter(formatter)
        logger.addHandler(fh)

        sh = logging.StreamHandler()
        sh.setFormatter(formatter)
        logger.addHandler(sh)

    class LockedLogger:
        def __getattr__(self, name):
            def wrapper(*args, **kwargs):
                with _log_lock:
                    return getattr(logger, name)(*args, **kwargs)
            return wrapper
    return LockedLogger()
