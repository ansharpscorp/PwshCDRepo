TeamsCallAnalysis/
│
├── main.py
├── io_handler_async.py
├── processor.py
├── utils.py
├── logger.py
├── config.json
├── columns.yml
├── requirements.txt
└── _Logs/
