from datetime import datetime, timedelta

def generate_date_range(start, end):
    start_date = datetime.strptime(start, "%Y-%m-%d")
    end_date = datetime.strptime(end, "%Y-%m-%d")
    days = []
    while start_date <= end_date:
        days.append(start_date.strftime("%Y%m%d"))
        start_date += timedelta(days=1)
    return days
