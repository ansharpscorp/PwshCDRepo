# fetcher.py
import os
import aiohttp
import asyncio
import json
from config import OUTPUT_DIR, GRAPH_URL, MAX_PARALLEL_REQUESTS, RETRY_LIMIT
from token_helper import get_access_token

async def fetch_with_retries(session, url, retries=RETRY_LIMIT):
    for attempt in range(retries):
        try:
            async with session.get(url) as resp:
                if resp.status == 200:
                    return await resp.json()
                else:
                    await asyncio.sleep(2 ** attempt)
        except Exception as e:
            await asyncio.sleep(2 ** attempt)
    return None

async def fetch_call_records(session, token, start, end):
    headers = {"Authorization": f"Bearer {token}"}
    url = f"{GRAPH_URL}?$filter=startDateTime ge {start} and startDateTime lt {end}"
    records = []
    while url:
        data = await fetch_with_retries(session, url)
        if data:
            records.extend(data.get("value", []))
            url = data.get("@odata.nextLink")
        else:
            break
    return records

async def fetch_expansions(session, token, call_id):
    headers = {"Authorization": f"Bearer {token}"}
    session_url = f"{GRAPH_URL}/{call_id}/sessions?$expand=segments"
    participants_url = f"{GRAPH_URL}/{call_id}/participants_v2"

    session_data = await fetch_with_retries(session, session_url)
    participants_data = await fetch_with_retries(session, participants_url)

    return {
        "sessions": session_data.get("value", []) if session_data else [],
        "participants_v2": participants_data.get("value", []) if participants_data else []
    }

async def process_record(session, token, record, date_folder):
    call_id = record.get("id")
    if not call_id:
        return
    filepath = os.path.join(date_folder, f"{call_id}.json")
    if os.path.exists(filepath):
        return

    expansions = await fetch_expansions(session, token, call_id)
    output = {
        "endDateTime": record.get("endDateTime"),
        "id": call_id,
        "joinWebUrl": record.get("joinWebUrl"),
        "lastModifiedDateTime": record.get("lastModifiedDateTime"),
        "modalities": record.get("modalities"),
        "organizer": record.get("organizer"),
        "participants": record.get("participants"),
        "startDateTime": record.get("startDateTime"),
        "type": record.get("type"),
        "version": record.get("version"),
        "participants_v2": expansions["participants_v2"],
        "sessions": expansions["sessions"]
    }

    os.makedirs(date_folder, exist_ok=True)
    with open(filepath, 'w') as f:
        json.dump(output, f, indent=2)
