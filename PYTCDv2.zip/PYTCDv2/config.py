# config.py
OUTPUT_DIR = "_cdrjsons"
CLIENT_ID = "<your-client-id>"
CLIENT_SECRET = "<your-client-secret>"
TENANT_ID = "<your-tenant-id>"
SCOPE = "https://graph.microsoft.com/.default"
GRAPH_URL = "https://graph.microsoft.com/v1.0/communications/callRecords"
MAX_PARALLEL_REQUESTS = 4
RETRY_LIMIT = 5