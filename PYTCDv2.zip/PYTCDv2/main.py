# main.py
import os
import sys
import asyncio
from datetime import datetime, timedelta
from token_helper import get_access_token
from fetcher import fetch_call_records, process_record
from config import OUTPUT_DIR, MAX_PARALLEL_REQUESTS
import aiohttp

async def process_interval(date, start_time, end_time, token):
    start = f"{date}T{start_time}:00Z"
    end = f"{date}T{end_time}:00Z"
    date_folder = os.path.join(OUTPUT_DIR, date[:4], date[5:7], date[8:10])

    async with aiohttp.ClientSession() as session:
        records = await fetch_call_records(session, token, start, end)
        sem = asyncio.Semaphore(MAX_PARALLEL_REQUESTS)

        async def sem_task(record):
            async with sem:
                await process_record(session, token, record, date_folder)

        await asyncio.gather(*(sem_task(rec) for rec in records))

async def main(date, start_hour, end_hour):
    token = get_access_token()
    tasks = []
    for hour in range(start_hour, end_hour):
        for quarter in [0, 15, 30, 45]:
            start_time = f"{hour:02}:{quarter:02}"
            end_time = (datetime.strptime(start_time, "%H:%M") + timedelta(minutes=15)).strftime("%H:%M")
            tasks.append(process_interval(date, start_time, end_time, token))
    await asyncio.gather(*tasks)

if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("Usage: python main.py <YYYY-MM-DD> <startHour> <endHour>")
    else:
        date = sys.argv[1]
        start_hour = int(sys.argv[2])
        end_hour = int(sys.argv[3])
        asyncio.run(main(date, start_hour, end_hour))