callrecord-etl/
├─ main.py
├─ flattener.py
├─ azure_io.py
├─ settings_loader.py
├─ log_utils.py              <-- NEW (structured JSONL logging)
├─ columns.yml
├─ settings.json
├─ requirements.txt
└─ README.md
