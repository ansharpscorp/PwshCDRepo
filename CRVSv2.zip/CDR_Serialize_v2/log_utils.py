from __future__ import annotations
import os
import json
import logging
from datetime import datetime
from typing import Tuple

class JsonLineFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        # record.msg may be a dict or a string; we normalize to dict with base fields
        base = {
            "ts": datetime.utcnow().isoformat(timespec="milliseconds") + "Z",
            "level": record.levelname,
        }
        msg = record.getMessage()
        # If the message was passed as a dict (we always do), it's already JSON in msg;
        # but logging coerces dict to str, so we carry full dict via record.__dict__['event']
        event = getattr(record, "event", None)
        if isinstance(event, dict):
            base.update(event)
        else:
            base["message"] = msg
        return json.dumps(base, ensure_ascii=False)

def setup_structured_logger(log_dir: str = "logs") -> Tuple[logging.Logger, str]:
    os.makedirs(log_dir, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M")
    log_path = os.path.join(log_dir, f"run_{ts}.log")

    logger = logging.getLogger("cdr_etl")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()  # avoid duplicate handlers if re-run in same process

    fh = logging.FileHandler(log_path, encoding="utf-8")
    fh.setLevel(logging.INFO)
    fh.setFormatter(JsonLineFormatter())
    logger.addHandler(fh)

    # Optional: keep console clean; tqdm shows progress so we skip console handler
    return logger, log_path

def jlog(logger: logging.Logger, level: int, event_type: str, **fields):
    # Helper to send a JSON event; use logger._log to attach dict
    payload = {"event": event_type}
    payload.update(fields)
    logger._log(level, msg="", args=(), extra={"event": payload})
