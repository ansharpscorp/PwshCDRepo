from __future__ import annotations
from typing import Any, Dict, List, Tuple
import copy

def _get_by_path(obj: Any, path: str, default=None):
    """
    Safely fetch nested value via dotted path 'a.b.c'.
    If any parent node is missing/None (e.g., 'a.b' is None), returns default (None).
    Guarantees:
      - if sessions is null -> sessions.* = None
      - if phone is null    -> ...phone.id = None
    """
    cur = obj
    for part in path.split("."):
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            return default
    return cur

def normalize_name(path: str) -> str:
    """Replace '.' with '_' for Parquet column names."""
    return path.replace(".", "_")

def build_rows(call_json: Dict[str, Any],
               top_columns: List[str],
               session_columns: List[str]) -> Tuple[List[str], List[Dict[str, Any]]]:
    """
    Row policy:
      - One row per sessions[] element.
      - If sessions missing/null/empty -> emit single row with all sessions.* = None.
    """
    col_order: List[str] = []
    col_map: Dict[str, str] = {}

    for p in top_columns + session_columns:
        if p not in col_map:
            col_map[p] = normalize_name(p)
            col_order.append(col_map[p])

    # top-level (callRecord) fields
    base_row: Dict[str, Any] = {}
    for p in top_columns:
        base_row[col_map[p]] = _get_by_path(call_json, p, None)

    sessions = call_json.get("sessions") or []
    rows: List[Dict[str, Any]] = []

    if not isinstance(sessions, list) or len(sessions) == 0:
        row = copy.copy(base_row)
        for sp in session_columns:
            row[col_map[sp]] = None
        rows.append(row)
        return col_order, rows

    for sess in sessions:
        row = copy.copy(base_row)
        for sp in session_columns:
            if sp.startswith("sessions.") and isinstance(sess, dict):
                inner = sp[len("sessions."):]
                row[col_map[sp]] = _get_by_path(sess, inner, None)
            else:
                row[col_map[sp]] = _get_by_path(call_json, sp, None)
        rows.append(row)

    return col_order, rows
