### Runtime feedback
- **Progress bar** shows end-to-end progress and throughput.
- A structured **JSON-lines log** is written to `logs/run_YYYYMMDD_HHMM.log`.

Each line is a JSON object, e.g.:
```json
{"ts":"2025-10-04T08:31:22.345Z","level":"INFO","event":"run_started","settings_path":"settings.json",...}
{"ts":"2025-10-04T08:31:22.512Z","level":"INFO","event":"day_listed","day_prefix":"2025/Oct/04/","files":1234}
{"ts":"2025-10-04T08:31:30.102Z","level":"INFO","event":"file_processed","src_blob":"2025/Oct/04/CR123.json","dst_blob":"2025/Oct/04/CR123.parquet","rows":2}
{"ts":"2025-10-04T08:31:31.009Z","level":"ERROR","event":"file_error","src_blob":"2025/Oct/04/bad.json","error":"Expecting value: line 1 column 1 (char 0)"}
{"ts":"2025-10-04T08:31:40.443Z","level":"INFO","event":"run_finished","submitted":1523,"success":1520,"failed":3,"log_path":"logs/run_20251004_0831.log"}
