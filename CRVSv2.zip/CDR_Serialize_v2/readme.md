# CallRecord JSON → Parquet (Parallel, Date-Ranged, Mirrored Paths)

Reads Microsoft Graph callRecords JSON from an Azure Blob container (e.g., `CDR/YYYY/MMM/dd/*.json`), flattens required fields (configured in `columns.yml`), **explodes sessions** (one row per session; if no sessions → a single row with `sessions.* = null`), and writes Parquet back to another container (e.g., `CDRParquet/YYYY/MMM/dd/*.parquet`), preserving the **same day folder structure**.

## Features
- Parallel IO (ThreadPoolExecutor) for **high volume**.
- **Date range** batching (inclusive) across `YYYY/MMM/dd` folders.
- **Mirrored paths**: destination day path matches source day path.
- **Dot-path flattening** (e.g., `organizer_v2.identity.user.userPrincipalName`).
- **Null safety**: missing parent → all children null (e.g., if `phone` is null → `...phone.id = null`).
- Secrets in `settings.json`: plain / `b64:` base64 / `env:` environment variable.

## Project Layout
