from __future__ import annotations
import os
import json
import base64
from typing import Dict, Any, Optional

def _resolve_secret(value: Optional[str]) -> Optional[str]:
    """
    Resolve secret tokens:
      - "env:NAME"  -> os.environ["NAME"]
      - "b64:..."   -> base64-decoded
      - plain text  -> as-is
      - None/""     -> None
    """
    if not value:
        return None
    if isinstance(value, str):
        if value.startswith("env:"):
            return os.getenv(value[4:], None)
        if value.startswith("b64:"):
            try:
                return base64.b64decode(value[4:]).decode("utf-8")
            except Exception:
                return None
        return value
    return None

def load_settings(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    auth = cfg.get("auth", {}) or {}
    secrets = cfg.get("secrets", {}) or {}

    conn_str = _resolve_secret(auth.get("connection_string"))
    account_key = _resolve_secret(secrets.get("account_key"))
    sas_token = _resolve_secret(secrets.get("sas_token"))

    cfg["_resolved"] = {
        "connection_string": conn_str,
        "account_key": account_key,
        "sas_token": sas_token,
    }
    return cfg

def apply_auth_env(settings: Dict[str, Any]) -> None:
    """
    If auth.mode == 'connection_string' and we have one, export AZURE_STORAGE_CONNECTION_STRING.
    """
    mode = (settings.get("auth", {}).get("mode") or "").lower()
    conn_str = settings.get("_resolved", {}).get("connection_string")
    if mode == "connection_string" and conn_str:
        os.environ["AZURE_STORAGE_CONNECTION_STRING"] = conn_str
