from __future__ import annotations
import argparse
import os
import io
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Optional, Iterable, Tuple
import yaml
import orjson
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from tqdm import tqdm
from datetime import date, timedelta
import calendar
import logging

from azure.identity import DefaultAzureCredential
from azure_io import make_container_client, iter_json_blobs, download_text, upload_bytes
from flattener import build_rows
from settings_loader import load_settings, apply_auth_env
from log_utils import setup_structured_logger, jlog

def parse_args():
    p = argparse.ArgumentParser(description="Parallel callRecord JSON → Parquet (date-ranged, path-mirrored)")
    p.add_argument("--settings", default="settings.json", help="Path to settings.json")
    p.add_argument("--columns-yaml", default="columns.yml")
    p.add_argument("--max-workers", type=int, default=min(32, (os.cpu_count() or 8) * 5))
    p.add_argument("--limit", type=int, default=0, help="Total limit of files across all days (0=no limit)")
    return p.parse_args()

def load_config(path: str):
    with open(path, "r", encoding="utf-8") as f:
        y = yaml.safe_load(f)
    cols = y.get("columns", [])
    sess_cols = y.get("session_columns", [])
    if not isinstance(cols, list) or not isinstance(sess_cols, list):
        raise ValueError("columns.yml must contain 'columns' and 'session_columns' lists")
    return cols, sess_cols

def to_parquet_bytes(df: pd.DataFrame) -> bytes:
    table = pa.Table.from_pandas(df, preserve_index=False)
    sink = io.BytesIO()
    pq.write_table(table, sink, compression="snappy")
    return sink.getvalue()

def derive_output_name(input_blob_name: str, dst_prefix: str) -> str:
    base = os.path.basename(input_blob_name)
    stem = base[:-5] if base.lower().endswith(".json") else base
    out_name = f"{stem}.parquet"
    return f"{dst_prefix.rstrip('/')}/{out_name}" if dst_prefix else out_name

def process_one(blob_name: str,
                src_cc,
                dst_cc,
                columns: List[str],
                session_columns: List[str],
                dst_prefix: str,
                logger: logging.Logger) -> Optional[str]:
    try:
        raw = download_text(src_cc, blob_name)
        rec = orjson.loads(raw)

        ordered_cols, rows = build_rows(rec, columns, session_columns)
        if not rows:
            jlog(logger, logging.INFO, "file_processed",
                 src_blob=blob_name, dst_blob=None, rows=0, note="no_rows_built")
            return None

        df = pd.DataFrame(rows, columns=ordered_cols)
        parquet_bytes = to_parquet_bytes(df)
        dst_blob = derive_output_name(blob_name, dst_prefix)
        upload_bytes(dst_cc, dst_blob, parquet_bytes, overwrite=True)

        jlog(logger, logging.INFO, "file_processed",
             src_blob=blob_name, dst_blob=dst_blob, rows=len(df))

        return dst_blob
    except Exception as e:
        jlog(logger, logging.ERROR, "file_error",
             src_blob=blob_name, error=str(e))
        return f"ERROR::{blob_name}::{e}"

def _month_abbr_en(month_int: int) -> str:
    return calendar.month_abbr[month_int]  # 'Jan', 'Feb', 'Mar', ...

def _date_prefix(d: date) -> str:
    return f"{d.year}/{_month_abbr_en(d.month)}/{d.day:02d}/"  # "YYYY/MMM/dd/"

def _join_prefix(root_prefix: str, date_prefix: str) -> str:
    root = (root_prefix or "").strip("/")
    dp = date_prefix.strip("/")
    joined = f"{root}/{dp}" if root else dp
    return joined if joined.endswith("/") else joined + "/"

def _iter_dates(start_str: str, end_str: str) -> Iterable[date]:
    y1, m1, d1 = map(int, start_str.split("-"))
    y2, m2, d2 = map(int, end_str.split("-"))
    start_d = date(y1, m1, d1)
    end_d = date(y2, m2, d2)
    if end_d < start_d:
        raise ValueError("date_range.end is before date_range.start")
    cur = start_d
    one = timedelta(days=1)
    while cur <= end_d:
        yield cur
        cur += one

def main():
    args = parse_args()

    # Setup structured logger
    logger, log_path = setup_structured_logger(log_dir="logs")

    settings = load_settings(args.settings)
    apply_auth_env(settings)  # may set AZURE_STORAGE_CONNECTION_STRING

    use_default_cred = bool(settings.get("auth", {}).get("use_default_credential", False))
    credential = DefaultAzureCredential() if use_default_cred else None
    sas = settings.get("_resolved", {}).get("sas_token")

    src = settings.get("source", {})
    dst = settings.get("destination", {})

    # Emit run_started
    jlog(logger, logging.INFO, "run_started",
         settings_path=args.settings,
         columns_yaml=args.columns_yaml,
         max_workers=args.max_workers,
         limit=args.limit,
         source_container=src.get("container"),
         destination_container=dst.get("container"))

    src_cc = make_container_client(
        account_url=src.get("account_url"),
        container=src.get("container"),
        credential=credential,
        sas_token=sas
    )
    dst_cc = make_container_client(
        account_url=dst.get("account_url"),
        container=dst.get("container"),
        credential=credential,
        sas_token=sas
    )

    columns, session_columns = load_config(args.columns_yaml)

    root_src = src.get("root_prefix") or ""
    root_dst = dst.get("root_prefix") or ""

    dr = (src.get("date_range") or {})
    start_s = dr.get("start")
    end_s = dr.get("end")
    if not start_s or not end_s:
        raise ValueError("Please set source.date_range.start and source.date_range.end in settings.json (YYYY-MM-DD).")

    # Build all (src_prefix, dst_prefix) day pairs
    day_pairs: List[Tuple[str, str]] = []
    for d in _iter_dates(start_s, end_s):
        day = _date_prefix(d)
        src_prefix = _join_prefix(root_src, day)
        dst_prefix = _join_prefix(root_dst, day)
        day_pairs.append((src_prefix, dst_prefix))

    total_limit = args.limit if args.limit and args.limit > 0 else None
    successes = failures = 0
    submitted = 0

    # Log day listings
    for src_prefix, _ in day_pairs:
        jlog(logger, logging.INFO, "day_planned", day_prefix=src_prefix)

    with ThreadPoolExecutor(max_workers=args.max_workers) as ex:
        futures = {}

        for src_prefix, dst_prefix in day_pairs:
            blobs = list(iter_json_blobs(src_cc, prefix=src_prefix))
            jlog(logger, logging.INFO, "day_listed", day_prefix=src_prefix, files=len(blobs))
            if not blobs:
                continue

            if total_limit is not None:
                remaining = total_limit - submitted
                if remaining <= 0:
                    break
                blobs = blobs[:remaining]

            for b in blobs:
                fut = ex.submit(process_one, b, src_cc, dst_cc, columns, session_columns, dst_prefix, logger)
                futures[fut] = b
            submitted += len(blobs)

        for fut in tqdm(as_completed(futures), total=len(futures), unit="file"):
            res = fut.result()
            if res and res.startswith("ERROR::"):
                failures += 1
            else:
                successes += 1

    jlog(logger, logging.INFO, "run_finished",
         submitted=submitted, success=successes, failed=failures, log_path=log_path)

    print(f"Log written to: {log_path}")
    print(f"Done. Submitted: {submitted}, Success: {successes}, Failed: {failures}")

if __name__ == "__main__":
    main()
