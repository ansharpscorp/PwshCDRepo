python main.py --settings settings.json --columns-yaml columns.yml --max-workers 64

python make_b64.py

Plain:
 DefaultEndpointsProtocol=https;AccountName=xxxxxxx;AccountKey=aaaaaaaaaaaaaaaaaaaaaaaa;EndpointSuffix=core.windows.net

Base64 encoded (add 'b64:' in settings.json):

b64:RGVmYXVsdEVuZHBvaW50c1Byb3RvY29sPWh0dHBzO0FjY291bnROYW1lPXh4eHh4eHg7QWNjb3VudEtleT1hYWFhYWFhYWFhYWFhYWFhYWFhYWFhYTtFbmRwb2ludFN1ZmZpeD1jb3JlLndpbmRvd3MubmV0
