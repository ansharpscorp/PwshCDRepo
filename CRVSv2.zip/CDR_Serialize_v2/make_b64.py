import base64

def make_b64_connection_string():
    # Paste your plain connection string here
    plain = (
        "DefaultEndpointsProtocol=https;"
        "AccountName=xxxxxxx;"
        "AccountKey=aaaaaaaaaaaaaaaaaaaaaaaa;"
        "EndpointSuffix=core.windows.net"
    )

    encoded = base64.b64encode(plain.encode("utf-8")).decode("utf-8")
    print("Plain:\n", plain)
    print("\nBase64 encoded (add 'b64:' in settings.json):\n")
    print("b64:" + encoded)

if __name__ == "__main__":
    make_b64_connection_string()
