# Delta (no Java) — Build/Append Delta Lake on ADLS Gen2

Creates/updates a Delta Lake dataset from Parquet in YYYY/MM/dd/*.parquet without Spark/Java (delta-rs).

Install:
  pip install -r requirements.txt

Run:
  python app.py
