import os, json, re
from typing import Dict, Set, List
import pandas as pd
import fsspec
import pyarrow.fs as pafs
import pyarrow.dataset as ds
from deltalake import DeltaTable, write_deltalake

def load_cfg(path="settings.json"):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def abfss(path: str) -> str:
    return path.rstrip("/")

def _azure_storage_options(cfg: Dict) -> Dict:
    account = cfg["adls"]["account_name"]
    auth = cfg["adls"]["auth"]
    so = {"azure_storage_account_name": account}
    method = auth.get("method", "service_principal").lower()
    if method == "sas" and auth.get("sas_token"):
        so["azure_storage_sas"] = auth["sas_token"].lstrip("?")
    elif method == "account_key" and auth.get("account_key"):
        so["azure_storage_access_key"] = auth["account_key"]
    elif method == "service_principal":
        os.environ["AZURE_TENANT_ID"] = auth["tenant_id"]
        os.environ["AZURE_CLIENT_ID"] = auth["client_id"]
        os.environ["AZURE_CLIENT_SECRET"] = auth["client_secret"]
    else:
        raise ValueError("Invalid Azure auth configuration for delta-rs.")
    return so

def _fsspec_storage_options(cfg: Dict) -> Dict:
    account = cfg["adls"]["account_name"]
    auth = cfg["adls"]["auth"]
    method = auth.get("method", "service_principal").lower()
    if method == "sas" and auth.get("sas_token"):
        return {"account_name": account, "sas_token": auth["sas_token"]}
    elif method == "account_key" and auth.get("account_key"):
        return {"account_name": account, "account_key": auth["account_key"]}
    elif method == "service_principal":
        return {
            "account_name": account,
            "tenant_id": auth["tenant_id"],
            "client_id": auth["client_id"],
            "client_secret": auth["client_secret"],
        }
    else:
        raise ValueError("Invalid Azure auth configuration for fsspec/adlfs.")

def _pyarrow_fs_from_fsspec(storage_options: dict) -> pafs.FileSystem:
    fs = fsspec.filesystem("abfs", **storage_options)
    return pafs.PyFileSystem(pafs.FSSpecHandler(fs))

def list_source_dates(input_base: str, storage_options: Dict) -> List[str]:
    fs = fsspec.filesystem("abfs", **storage_options)
    try:
        years = [p for p in fs.ls(input_base) if re.search(r"/\d{4}$", p)]
    except FileNotFoundError:
        return []
    dates = set()
    for y in years:
        try:
            months = [p for p in fs.ls(y) if re.search(r"/\d{2}$", p)]
        except FileNotFoundError:
            months = []
        for m in months:
            try:
                days = [p for p in fs.ls(m) if re.search(r"/\d{2}$", p)]
            except FileNotFoundError:
                days = []
            for d in days:
                try:
                    files = [p for p in fs.ls(d) if p.lower().endswith(".parquet")]
                except FileNotFoundError:
                    files = []
                if files:
                    parts = d.strip("/").split("/")[-3:]
                    dates.add(f"{parts[0]}-{parts[1]}-{parts[2]}")
    return sorted(dates)

def existing_delta_dates(delta_path: str, storage_options: Dict) -> Set[str]:
    try:
        dt = DeltaTable(delta_path, storage_options=storage_options)
    except Exception:
        return set()
    try:
        pdf = dt.to_pandas(columns=["Date"])
    except Exception:
        return set()
    if "Date" not in pdf.columns:
        return set()
    return set(pd.to_datetime(pdf["Date"]).dt.strftime("%Y-%m-%d").unique())

def read_dates_as_pandas(input_base: str, want_dates: List[str], storage_options: Dict) -> pd.DataFrame:
    pyfs = _pyarrow_fs_from_fsspec(storage_options)
    dataset = ds.dataset(input_base, format="parquet", filesystem=pyfs, partitioning="hive")
    dfs = []
    for iso in want_dates:
        y, m, d = iso.split("-")
        exprs = [
            (ds.field("YYYY") == y) & (ds.field("MM") == m) & (ds.field("dd") == d),
            (ds.field("year") == int(y)) & (ds.field("month") == int(m)) & (ds.field("day") == int(d)),
        ]
        got = False
        for expr in exprs:
            try:
                tbl = dataset.to_table(filter=expr)
                if tbl.num_rows > 0:
                    df = tbl.to_pandas(split_blocks=True, self_destruct=True)
                    if "Date" not in df.columns:
                        df["Date"] = f"{y}-{m}-{d}"
                    dfs.append(df); got = True; break
            except Exception:
                continue
        if not got:
            folder = f"{input_base}/{y}/{m}/{d}"
            try:
                subds = ds.dataset(folder, format="parquet", filesystem=pyfs)
                tbl = subds.to_table()
                if tbl.num_rows > 0:
                    df = tbl.to_pandas(split_blocks=True, self_destruct=True)
                    if "Date" not in df.columns:
                        df["Date"] = f"{y}-{m}-{d}"
                    dfs.append(df)
            except Exception:
                pass
    if not dfs:
        return pd.DataFrame()
    out = pd.concat(dfs, ignore_index=True)
    out["Date"] = pd.to_datetime(out["Date"]).dt.strftime("%Y-%m-%d")
    return out

def main():
    cfg = load_cfg()
    input_base = abfss(cfg["paths"]["input_base"])
    delta_path = cfg["paths"]["output_delta"]
    mode = cfg["write"].get("mode", "append").lower()
    partition_by = cfg["write"].get("partition_by", ["Date"])

    so_read = _fsspec_storage_options(cfg)
    so_delta = _azure_storage_options(cfg)

    if mode == "overwrite":
        src_dates = list_source_dates(input_base, so_read)
        df = read_dates_as_pandas(input_base, src_dates, so_read)
        if df.empty:
            print("No source data found."); return
        if partition_by == ["YYYY","MM","dd"]:
            dt = pd.to_datetime(df["Date"])
            df["YYYY"] = dt.dt.year.astype(str)
            df["MM"]   = dt.dt.month.astype(str).str.zfill(2)
            df["dd"]   = dt.dt.day.astype(str).str.zfill(2)
        write_deltalake(
            delta_path, data=df, mode="overwrite",
            storage_options=so_delta,
            partition_by=partition_by,
            writer_properties={"parquet.compression": "snappy"}
        )
        print(f"✅ Overwrote Delta dataset at {delta_path}. Rows: {len(df)}"); return

    have = existing_delta_dates(delta_path, so_delta)
    src_dates = set(list_source_dates(input_base, so_read))
    new_dates = sorted(src_dates - have)
    if not new_dates:
        print("No new dates to append. ✅"); return

    df = read_dates_as_pandas(input_base, new_dates, so_read)
    if df.empty:
        print("No rows read for new dates; nothing to write."); return

    if partition_by == ["YYYY","MM","dd"]:
        dt = pd.to_datetime(df["Date"])
        df["YYYY"] = dt.dt.year.astype(str)
        df["MM"]   = dt.dt.month.astype(str).str.zfill(2)
        df["dd"]   = dt.dt.day.astype(str).str.zfill(2)

    write_deltalake(
        delta_path, data=df, mode="append",
        storage_options=so_delta,
        partition_by=partition_by,
        writer_properties={"parquet.compression": "snappy"}
    )
    print(f"✅ Appended {len(df)} rows to {delta_path} for {len(new_dates)} new day(s).")

if __name__ == "__main__":
    main()
