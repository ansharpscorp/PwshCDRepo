# teams_cdr_downloader/token_helper.py
import requests
from config import CLIENT_ID, CLIENT_SECRET, TENANT_ID, SCOPE

def get_access_token():
    url = f"https://login.microsoftonline.com/{TENANT_ID}/oauth2/v2.0/token"
    data = {
        'client_id': CLIENT_ID,
        'scope': ' '.join(SCOPE),
        'client_secret': CLIENT_SECRET,
        'grant_type': 'client_credentials'
    }
    response = requests.post(url, data=data)
    response.raise_for_status()
    return response.json().get('access_token')