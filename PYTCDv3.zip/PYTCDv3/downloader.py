# downloader.py
import sys
import asyncio
from processor import process_day

if __name__ == '__main__':
    if len(sys.argv) != 4:
        print("Usage: python downloader.py <date> <startHour> <endHour>")
        sys.exit(1)

    date = sys.argv[1]
    start_hour = int(sys.argv[2])
    end_hour = int(sys.argv[3])

    asyncio.run(process_day(date, start_hour, end_hour))