# teams_cdr_downloader/fetcher.py
import requests
import json
import os
import csv
from logger import logger
from config import GRAPH_URL, OUTPUT_ROOT, FAILED_CSV
from tenacity import retry, stop_after_attempt, wait_exponential

@retry(stop=stop_after_attempt(5), wait=wait_exponential(multiplier=1, min=4, max=10))
def get_json(url, headers):
    response = requests.get(url, headers=headers)
    response.raise_for_status()
    return response.json()

def save_failed_record(call_id, reason):
    with open(FAILED_CSV, mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([call_id, reason])

def process_record(token, rec, date_path):
    headers = {'Authorization': f'Bearer {token}'}
    call_id = rec.get('id')
    if not call_id:
        logger.error('No ID in record')
        return

    output_dir = os.path.join(OUTPUT_ROOT, *date_path)
    os.makedirs(output_dir, exist_ok=True)
    file_path = os.path.join(output_dir, f"{call_id}.json")
    if os.path.exists(file_path):
        logger.info(f"Skipping {file_path}")
        return

    try:
        sessions_url = f"{GRAPH_URL}/{call_id}/sessions?$expand=segments"
        participants_url = f"{GRAPH_URL}/{call_id}/participants_v2"
        sessions = get_json(sessions_url, headers).get('value', [])
        participants_v2 = get_json(participants_url, headers).get('value', [])

        record_obj = {
            "endDateTime": rec.get("endDateTime"),
            "id": call_id,
            "joinWebUrl": rec.get("joinWebUrl"),
            "lastModifiedDateTime": rec.get("lastModifiedDateTime"),
            "modalities": rec.get("modalities"),
            "organizer": rec.get("organizer"),
            "participants": rec.get("participants"),
            "startDateTime": rec.get("startDateTime"),
            "type": rec.get("type"),
            "version": rec.get("version"),
            "participants_v2": participants_v2,
            "sessions": sessions
        }

        with open(file_path, 'w') as f:
            json.dump(record_obj, f, indent=2)

    except Exception as e:
        logger.error(f"Error processing {call_id}: {e}")
        save_failed_record(call_id, str(e))
