CLIENT_ID = "<your-client-id>"
CLIENT_SECRET = "<your-client-secret>"
TENANT_ID = "<your-tenant-id>"
SCOPE = ["https://graph.microsoft.com/.default"]
GRAPH_URL = "https://graph.microsoft.com/v1.0/communications/callRecords"
OUTPUT_ROOT = "_cdrjsons"
FAILED_CSV = "failed_records.csv"
MAX_PARALLELISM = 4