# teams_cdr_downloader/processor.py
from fetcher import process_record, get_json
from token_helper import get_access_token
from logger import logger
from config import GRAPH_URL, MAX_PARALLELISM
import asyncio
import aiohttp
from datetime import datetime, timedelta
import os

async def fetch_and_process_interval(token, start_iso, end_iso, date_path):
    url = f"{GRAPH_URL}?$filter=startDateTime ge {start_iso} and startDateTime lt {end_iso}"
    headers = {'Authorization': f'Bearer {token}'}
    session = aiohttp.ClientSession(headers=headers)
    records = []
    try:
        while url:
            async with session.get(url) as resp:
                resp.raise_for_status()
                json_data = await resp.json()
                records.extend(json_data.get('value', []))
                url = json_data.get('@odata.nextLink')
    except Exception as e:
        logger.error(f"Interval {start_iso} error: {e}")
    finally:
        await session.close()

    loop = asyncio.get_running_loop()
    sem = asyncio.Semaphore(MAX_PARALLELISM)

    async def bound_process(rec):
        async with sem:
            await loop.run_in_executor(None, process_record, token, rec, date_path)

    await asyncio.gather(*(bound_process(r) for r in records))

async def process_day(date_str, start_hour, end_hour):
    token = get_access_token()
    date = datetime.strptime(date_str, "%Y-%m-%d")
    date_path = [date.strftime("%Y"), date.strftime("%m"), date.strftime("%d")]

    tasks = []
    for hour in range(start_hour, end_hour):
        for quarter in range(0, 60, 15):
            start_time = date + timedelta(hours=hour, minutes=quarter)
            end_time = start_time + timedelta(minutes=15)
            start_iso = start_time.strftime("%Y-%m-%dT%H:%M:%SZ")
            end_iso = end_time.strftime("%Y-%m-%dT%H:%M:%SZ")
            tasks.append(fetch_and_process_interval(token, start_iso, end_iso, date_path))

    await asyncio.gather(*tasks)